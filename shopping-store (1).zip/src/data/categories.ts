export interface Category {
  id: string;
  name: string;
  icon: string;
  gradient: string;
  productCount: number;
}

export const categories: Category[] = [
  { id: 'electronics', name: 'Electronics', icon: 'Smartphone', gradient: 'from-violet-500 to-purple-600', productCount: 156 },
  { id: 'fashion', name: 'Fashion', icon: 'Shirt', gradient: 'from-rose-400 to-pink-600', productCount: 243 },
  { id: 'home', name: 'Home & Living', icon: 'Home', gradient: 'from-amber-400 to-orange-500', productCount: 189 },
  { id: 'beauty', name: 'Beauty', icon: 'Sparkles', gradient: 'from-pink-400 to-fuchsia-500', productCount: 132 },
  { id: 'sports', name: 'Sports', icon: 'Dumbbell', gradient: 'from-emerald-400 to-green-600', productCount: 98 },
  { id: 'books', name: 'Books', icon: 'BookOpen', gradient: 'from-yellow-400 to-amber-500', productCount: 312 },
  { id: 'toys', name: 'Toys', icon: 'Gamepad2', gradient: 'from-cyan-400 to-sky-500', productCount: 76 },
  { id: 'grocery', name: 'Grocery', icon: 'ShoppingBasket', gradient: 'from-lime-400 to-green-500', productCount: 445 },
  { id: 'jewelry', name: 'Jewelry', icon: 'Gem', gradient: 'from-yellow-300 to-amber-500', productCount: 67 },
  { id: 'automotive', name: 'Automotive', icon: 'Car', gradient: 'from-slate-400 to-gray-600', productCount: 89 },
  { id: 'garden', name: 'Garden', icon: 'Flower2', gradient: 'from-teal-400 to-emerald-500', productCount: 54 },
  { id: 'music', name: 'Music', icon: 'Music', gradient: 'from-red-400 to-rose-500', productCount: 123 },
];

export function getCategoryById(id: string): Category | undefined {
  return categories.find((c) => c.id === id);
}

export function getCategoryByName(name: string): Category | undefined {
  return categories.find((c) => c.name === name);
}
