'use client';

import { create } from 'zustand';

export type Screen =
  | 'splash'
  | 'onboarding'
  | 'home'
  | 'categories'
  | 'product-listing'
  | 'product-detail'
  | 'cart'
  | 'checkout'
  | 'wishlist'
  | 'orders'
  | 'profile'
  | 'search'
  | 'auth'
  | 'notifications'
  | 'support'
  | 'faq'
  | 'privacy'
  | 'terms';

export interface Product {
  id: number;
  name: string;
  price: number;
  originalPrice: number;
  discount: number;
  rating: number;
  reviewCount: number;
  gradient: string;
  image: string;
  category: string;
  colors: string[];
  sizes: string[];
  description: string;
  features: string[];
  inStock: boolean;
  stockCount: number;
  isNew: boolean;
  isTrending: boolean;
  isBestSeller: boolean;
  deliveryDays: number;
}

export interface CartItem {
  product: Product;
  quantity: number;
  selectedColor: string;
  selectedSize: string;
}

export interface Order {
  id: string;
  items: CartItem[];
  total: number;
  status: 'pending' | 'shipped' | 'delivered' | 'cancelled';
  date: string;
  address: string;
  paymentMethod: string;
}

export interface UserProfile {
  name: string;
  email: string;
  avatar: string;
  phone: string;
}

interface AppState {
  currentScreen: Screen;
  previousScreen: Screen;
  selectedProductId: number | null;
  selectedCategory: string | null;
  cart: CartItem[];
  wishlist: number[];
  orders: Order[];
  user: UserProfile;
  onboardingCompleted: boolean;
  theme: 'light' | 'dark';
  notifications: Notification[];
  searchQuery: string;
  recentSearches: string[];
  checkoutStep: number;
  shippingAddress: {
    name: string;
    phone: string;
    address: string;
    city: string;
    zip: string;
  };
  shippingMethod: string;
  paymentMethod: string;

  navigateTo: (screen: Screen) => void;
  goBack: () => void;
  setSelectedProductId: (id: number | null) => void;
  setSelectedCategory: (cat: string | null) => void;
  addToCart: (product: Product, color?: string, size?: string, qty?: number) => void;
  removeFromCart: (productId: number) => void;
  updateCartQuantity: (productId: number, quantity: number) => void;
  clearCart: () => void;
  getCartTotal: () => number;
  getCartCount: () => number;
  toggleWishlist: (productId: number) => void;
  isInWishlist: (productId: number) => boolean;
  addOrder: (order: Order) => void;
  setOnboardingCompleted: (val: boolean) => void;
  toggleTheme: () => void;
  setTheme: (theme: 'light' | 'dark') => void;
  setSearchQuery: (q: string) => void;
  addRecentSearch: (q: string) => void;
  clearRecentSearches: () => void;
  setCheckoutStep: (step: number) => void;
  setShippingAddress: (addr: AppState['shippingAddress']) => void;
  setShippingMethod: (method: string) => void;
  setPaymentMethod: (method: string) => void;
  setUser: (user: UserProfile) => void;
}

export interface Notification {
  id: string;
  type: 'order' | 'promo' | 'price' | 'stock';
  title: string;
  message: string;
  time: string;
  read: boolean;
}

export const useAppStore = create<AppState>((set, get) => ({
  currentScreen: 'splash',
  previousScreen: 'home',
  selectedProductId: null,
  selectedCategory: null,
  cart: [],
  wishlist: [],
  orders: [],
  user: {
    name: 'Alex Johnson',
    email: 'alex@example.com',
    avatar: '',
    phone: '+1 234 567 890',
  },
  onboardingCompleted: false,
  theme: 'light',
  notifications: [
    { id: '1', type: 'order', title: 'Order Shipped!', message: 'Your order #ORD-2024-001 has been shipped and will arrive in 2-3 days.', time: '2h ago', read: false },
    { id: '2', type: 'promo', title: 'Flash Sale Alert!', message: 'Up to 50% off on Electronics. Limited time offer!', time: '5h ago', read: false },
    { id: '3', type: 'price', title: 'Price Drop!', message: 'An item in your wishlist has dropped in price.', time: '1d ago', read: true },
    { id: '4', type: 'stock', title: 'Back in Stock!', message: 'Premium Wireless Headphones are back in stock.', time: '2d ago', read: true },
    { id: '5', type: 'order', title: 'Order Delivered!', message: 'Your order #ORD-2024-005 has been delivered successfully.', time: '3d ago', read: true },
  ],
  searchQuery: '',
  recentSearches: ['Wireless earbuds', 'Running shoes', 'Smart watch', 'Coffee maker'],
  checkoutStep: 0,
  shippingAddress: { name: '', phone: '', address: '', city: '', zip: '' },
  shippingMethod: 'standard',
  paymentMethod: 'card',

  navigateTo: (screen) =>
    set((state) => ({
      previousScreen: state.currentScreen,
      currentScreen: screen,
    })),

  goBack: () =>
    set((state) => ({
      currentScreen: state.previousScreen,
      previousScreen: state.currentScreen,
    })),

  setSelectedProductId: (id) => set({ selectedProductId: id }),
  setSelectedCategory: (cat) => set({ selectedCategory: cat }),

  addToCart: (product, color, size, qty = 1) =>
    set((state) => {
      const existing = state.cart.find(
        (item) =>
          item.product.id === product.id &&
          item.selectedColor === (color || product.colors[0]) &&
          item.selectedSize === (size || product.sizes[0])
      );
      if (existing) {
        return {
          cart: state.cart.map((item) =>
            item.product.id === product.id &&
            item.selectedColor === existing.selectedColor &&
            item.selectedSize === existing.selectedSize
              ? { ...item, quantity: item.quantity + qty }
              : item
          ),
        };
      }
      return {
        cart: [
          ...state.cart,
          {
            product,
            quantity: qty,
            selectedColor: color || product.colors[0] || 'Default',
            selectedSize: size || product.sizes[0] || 'One Size',
          },
        ],
      };
    }),

  removeFromCart: (productId) =>
    set((state) => ({
      cart: state.cart.filter((item) => item.product.id !== productId),
    })),

  updateCartQuantity: (productId, quantity) =>
    set((state) => ({
      cart: quantity <= 0
        ? state.cart.filter((item) => item.product.id !== productId)
        : state.cart.map((item) =>
            item.product.id === productId ? { ...item, quantity } : item
          ),
    })),

  clearCart: () => set({ cart: [] }),

  getCartTotal: () => {
    const state = get();
    return state.cart.reduce(
      (total, item) => total + item.product.price * item.quantity,
      0
    );
  },

  getCartCount: () => {
    const state = get();
    return state.cart.reduce((count, item) => count + item.quantity, 0);
  },

  toggleWishlist: (productId) =>
    set((state) => ({
      wishlist: state.wishlist.includes(productId)
        ? state.wishlist.filter((id) => id !== productId)
        : [...state.wishlist, productId],
    })),

  isInWishlist: (productId) => get().wishlist.includes(productId),

  addOrder: (order) =>
    set((state) => ({
      orders: [order, ...state.orders],
      cart: [],
    })),

  setOnboardingCompleted: (val) => set({ onboardingCompleted: val }),
  toggleTheme: () =>
    set((state) => ({
      theme: state.theme === 'light' ? 'dark' : 'light',
    })),
  setTheme: (theme) => set({ theme }),

  setSearchQuery: (q) => set({ searchQuery: q }),
  addRecentSearch: (q) =>
    set((state) => ({
      recentSearches: [q, ...state.recentSearches.filter((s) => s !== q)].slice(
        0,
        10
      ),
    })),
  clearRecentSearches: () => set({ recentSearches: [] }),

  setCheckoutStep: (step) => set({ checkoutStep: step }),
  setShippingAddress: (addr) => set({ shippingAddress: addr }),
  setShippingMethod: (method) => set({ shippingMethod: method }),
  setPaymentMethod: (method) => set({ paymentMethod: method }),
  setUser: (user) => set({ user }),
}));
