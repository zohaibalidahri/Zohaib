'use client';

import { motion, AnimatePresence } from 'framer-motion';
import { useAppStore } from '@/store/useAppStore';
import { getProductById, products } from '@/data/products';
import { ArrowLeft, Heart, ShoppingCart, Trash2 } from 'lucide-react';
import { toast } from 'sonner';

export default function WishlistScreen() {
  const { wishlist, toggleWishlist, addToCart, navigateTo, goBack, setSelectedProductId } = useAppStore();

  const wishlistProducts = wishlist.map((id) => getProductById(id)).filter(Boolean);

  if (wishlistProducts.length === 0) {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <div className="sticky top-0 z-40 glass-strong">
          <div className="flex items-center gap-3 px-4 py-3">
            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={goBack}
              className="w-10 h-10 rounded-xl bg-secondary/50 flex items-center justify-center"
            >
              <ArrowLeft className="w-5 h-5 text-foreground" />
            </motion.button>
            <h1 className="text-lg font-bold text-foreground">My Wishlist</h1>
          </div>
        </div>
        <div className="flex-1 flex flex-col items-center justify-center gap-4 px-4">
          <motion.div
            initial={{ scale: 0.8 }}
            animate={{ scale: 1 }}
            className="w-24 h-24 rounded-3xl bg-secondary/50 flex items-center justify-center"
          >
            <Heart className="w-12 h-12 text-muted-foreground" />
          </motion.div>
          <h2 className="text-lg font-bold text-foreground">Your wishlist is empty</h2>
          <p className="text-sm text-muted-foreground text-center">Start adding items you love</p>
          <motion.button
            whileTap={{ scale: 0.97 }}
            onClick={() => navigateTo('home')}
            className="px-6 py-3 rounded-2xl bg-gradient-to-r from-[#c8956c] to-[#d4a574] text-white font-semibold text-sm"
          >
            Explore Products
          </motion.button>
        </div>
      </div>
    );
  }

  return (
    <div className="pb-24 min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-40 glass-strong">
        <div className="flex items-center gap-3 px-4 py-3">
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={goBack}
            className="w-10 h-10 rounded-xl bg-secondary/50 flex items-center justify-center"
          >
            <ArrowLeft className="w-5 h-5 text-foreground" />
          </motion.button>
          <h1 className="text-lg font-bold text-foreground">My Wishlist</h1>
          <span className="text-sm text-muted-foreground">({wishlistProducts.length} items)</span>
        </div>
      </div>

      {/* Wishlist Items */}
      <div className="px-4 mt-4 grid grid-cols-2 gap-3">
        <AnimatePresence>
          {wishlistProducts.map((product, i) => {
            if (!product) return null;
            return (
              <motion.div
                key={product.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
                transition={{ delay: i * 0.05 }}
                className="relative bg-card rounded-2xl card-shadow overflow-hidden"
              >
                <div
                  onClick={() => {
                    setSelectedProductId(product.id);
                    navigateTo('product-detail');
                  }}
                  className="cursor-pointer"
                >
                  <div className="relative aspect-square overflow-hidden">
                    <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
                    <motion.button
                      whileTap={{ scale: 0.8 }}
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleWishlist(product.id);
                        toast('Removed from wishlist', { description: product.name });
                      }}
                      className="absolute top-2 right-2 w-8 h-8 rounded-full bg-white/80 dark:bg-black/40 flex items-center justify-center"
                    >
                      <Heart className="w-4 h-4 fill-red-500 text-red-500" />
                    </motion.button>
                  </div>
                  <div className="p-3">
                    <h3 className="font-semibold text-sm text-foreground line-clamp-2">{product.name}</h3>
                    <div className="flex items-center gap-1.5 mt-1.5">
                      <span className="font-bold text-foreground">${product.price}</span>
                      {product.discount > 0 && (
                        <span className="text-xs text-muted-foreground line-through">${product.originalPrice}</span>
                      )}
                    </div>
                  </div>
                </div>
                <div className="px-3 pb-3">
                  <motion.button
                    whileTap={{ scale: 0.95 }}
                    onClick={(e) => {
                      e.stopPropagation();
                      addToCart(product);
                      toast('Added to cart', { description: product.name });
                    }}
                    className="w-full py-2 rounded-xl bg-gradient-to-r from-[#c8956c] to-[#d4a574] text-white text-xs font-semibold flex items-center justify-center gap-1.5"
                  >
                    <ShoppingCart className="w-3.5 h-3.5" /> Add to Cart
                  </motion.button>
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>
    </div>
  );
}
