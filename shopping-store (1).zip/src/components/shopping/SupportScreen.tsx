'use client';

import { motion } from 'framer-motion';
import { useAppStore } from '@/store/useAppStore';
import { ArrowLeft, Mail, MessageCircle, Phone, ChevronDown } from 'lucide-react';
import { useState } from 'react';

const faqItems = [
  { q: 'How do I track my order?', a: 'You can track your order by going to My Orders section and clicking on the specific order. You\'ll see real-time tracking updates there.' },
  { q: 'What is the return policy?', a: 'We offer a 7-day return policy on all products. Items must be in original condition with tags attached. Refunds are processed within 3-5 business days.' },
  { q: 'How long does delivery take?', a: 'Standard delivery takes 5-7 business days, Express takes 2-3 days, and Same Day delivery is available in select areas for orders placed before 2 PM.' },
  { q: 'Can I change my order after placing it?', a: 'You can modify your order within 1 hour of placing it. After that, please contact our support team for assistance.' },
  { q: 'How do I apply a coupon code?', a: 'Go to your cart, enter the coupon code in the designated field, and click Apply. The discount will be reflected in your order total.' },
  { q: 'Is my payment information secure?', a: 'Yes! We use 256-bit SSL encryption to protect your payment information. We never store your full card details on our servers.' },
];

const contactOptions = [
  { icon: Mail, label: 'Email Support', value: 'support@shoppingstore.com', color: 'bg-sky-500/10 text-sky-500' },
  { icon: MessageCircle, label: 'Live Chat', value: 'Available 24/7', color: 'bg-emerald-500/10 text-emerald-500' },
  { icon: Phone, label: 'Phone Support', value: '+1 (800) 123-4567', color: 'bg-amber-500/10 text-amber-500' },
];

export default function SupportScreen() {
  const { goBack } = useAppStore();
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  return (
    <div className="pb-24 min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-40 glass-strong">
        <div className="flex items-center gap-3 px-4 py-3">
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={goBack}
            className="w-10 h-10 rounded-xl bg-secondary/50 flex items-center justify-center"
          >
            <ArrowLeft className="w-5 h-5 text-foreground" />
          </motion.button>
          <h1 className="text-lg font-bold text-foreground">Help & Support</h1>
        </div>
      </div>

      <div className="px-4 mt-4 flex flex-col gap-6">
        {/* Contact Options */}
        <div className="flex flex-col gap-3">
          <h2 className="font-bold text-foreground">Contact Us</h2>
          {contactOptions.map((opt, i) => {
            const Icon = opt.icon;
            return (
              <motion.div
                key={opt.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                className="flex items-center gap-4 p-4 bg-card rounded-2xl card-shadow"
              >
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${opt.color}`}>
                  <Icon className="w-5 h-5" />
                </div>
                <div>
                  <p className="font-semibold text-sm text-foreground">{opt.label}</p>
                  <p className="text-xs text-muted-foreground">{opt.value}</p>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* FAQ */}
        <div>
          <h2 className="font-bold text-foreground mb-3">Frequently Asked Questions</h2>
          <div className="flex flex-col gap-2">
            {faqItems.map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                className="bg-card rounded-2xl card-shadow overflow-hidden"
              >
                <button
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                  className="w-full flex items-center justify-between p-4 text-left"
                >
                  <span className="font-medium text-sm text-foreground pr-4">{item.q}</span>
                  <motion.div
                    animate={{ rotate: openFaq === i ? 180 : 0 }}
                    transition={{ duration: 0.2 }}
                  >
                    <ChevronDown className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                  </motion.div>
                </button>
                <motion.div
                  initial={false}
                  animate={{
                    height: openFaq === i ? 'auto' : 0,
                    opacity: openFaq === i ? 1 : 0,
                  }}
                  transition={{ duration: 0.2 }}
                  className="overflow-hidden"
                >
                  <p className="px-4 pb-4 text-sm text-muted-foreground leading-relaxed">{item.a}</p>
                </motion.div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
