'use client';

import { motion } from 'framer-motion';
import { useAppStore, Notification } from '@/store/useAppStore';
import { ArrowLeft, Package, Tag, TrendingDown, RefreshCw } from 'lucide-react';
import { useState } from 'react';

const iconMap: Record<string, typeof Package> = {
  order: Package,
  promo: Tag,
  price: TrendingDown,
  stock: RefreshCw,
};

export default function NotificationsScreen() {
  const { notifications, goBack } = useAppStore();
  const [notifs, setNotifs] = useState(notifications);

  const markAsRead = (id: string) => {
    setNotifs(notifs.map((n) => n.id === id ? { ...n, read: true } : n));
  };

  const typeColors: Record<string, string> = {
    order: 'bg-sky-500/10 text-sky-500',
    promo: 'bg-amber-500/10 text-amber-500',
    price: 'bg-emerald-500/10 text-emerald-500',
    stock: 'bg-purple-500/10 text-purple-500',
  };

  return (
    <div className="pb-24 min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-40 glass-strong">
        <div className="flex items-center gap-3 px-4 py-3">
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={goBack}
            className="w-10 h-10 rounded-xl bg-secondary/50 flex items-center justify-center"
          >
            <ArrowLeft className="w-5 h-5 text-foreground" />
          </motion.button>
          <h1 className="text-lg font-bold text-foreground">Notifications</h1>
        </div>
      </div>

      <div className="px-4 mt-4 flex flex-col gap-3">
        {notifs.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 gap-3">
            <div className="w-20 h-20 rounded-2xl bg-secondary/50 flex items-center justify-center">
              <Package className="w-10 h-10 text-muted-foreground" />
            </div>
            <p className="text-muted-foreground font-medium">No notifications</p>
          </div>
        ) : (
          notifs.map((notif, i) => {
            const Icon = iconMap[notif.type] || Package;
            return (
              <motion.div
                key={notif.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                onClick={() => markAsRead(notif.id)}
                className={`flex items-start gap-3 p-4 rounded-2xl cursor-pointer transition-colors ${
                  notif.read ? 'bg-card' : 'bg-card card-shadow'
                }`}
              >
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${typeColors[notif.type]}`}>
                  <Icon className="w-5 h-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <h3 className={`text-sm font-semibold text-foreground ${!notif.read ? '' : 'opacity-70'}`}>{notif.title}</h3>
                    {!notif.read && <div className="w-2 h-2 rounded-full bg-[#c8956c] mt-1 flex-shrink-0" />}
                  </div>
                  <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{notif.message}</p>
                  <p className="text-[10px] text-muted-foreground mt-1">{notif.time}</p>
                </div>
              </motion.div>
            );
          })
        )}
      </div>
    </div>
  );
}
