'use client';

import { motion } from 'framer-motion';
import { useAppStore, Order } from '@/store/useAppStore';
import { ArrowLeft, Package, Truck, CheckCircle2, XCircle, RotateCcw } from 'lucide-react';
import { useState } from 'react';

const statusFilters = ['All', 'Pending', 'Shipped', 'Delivered', 'Cancelled'] as const;

export default function OrdersScreen() {
  const { orders, goBack, navigateTo } = useAppStore();
  const [activeFilter, setActiveFilter] = useState<string>('All');

  // Add some demo orders if none exist
  const demoOrders: Order[] = orders.length > 0 ? orders : [
    {
      id: 'ORD-2024-001',
      items: [],
      total: 129.99,
      status: 'shipped',
      date: '2024-12-15',
      address: '123 Main St, New York',
      paymentMethod: 'card',
    },
    {
      id: 'ORD-2024-002',
      items: [],
      total: 79.99,
      status: 'delivered',
      date: '2024-12-10',
      address: '123 Main St, New York',
      paymentMethod: 'wallet',
    },
    {
      id: 'ORD-2024-003',
      items: [],
      total: 45.99,
      status: 'pending',
      date: '2024-12-18',
      address: '123 Main St, New York',
      paymentMethod: 'cod',
    },
  ];

  const filteredOrders = activeFilter === 'All'
    ? demoOrders
    : demoOrders.filter((o) => o.status === activeFilter.toLowerCase());

  const statusConfig: Record<string, { color: string; icon: typeof Package; label: string }> = {
    pending: { color: 'text-amber-500 bg-amber-500/10', icon: Package, label: 'Pending' },
    shipped: { color: 'text-sky-500 bg-sky-500/10', icon: Truck, label: 'Shipped' },
    delivered: { color: 'text-emerald-500 bg-emerald-500/10', icon: CheckCircle2, label: 'Delivered' },
    cancelled: { color: 'text-red-500 bg-red-500/10', icon: XCircle, label: 'Cancelled' },
  };

  return (
    <div className="pb-24 min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-40 glass-strong">
        <div className="flex items-center gap-3 px-4 py-3">
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={goBack}
            className="w-10 h-10 rounded-xl bg-secondary/50 flex items-center justify-center"
          >
            <ArrowLeft className="w-5 h-5 text-foreground" />
          </motion.button>
          <h1 className="text-lg font-bold text-foreground">My Orders</h1>
        </div>

        {/* Filters */}
        <div className="flex gap-2 px-4 pb-3 overflow-x-auto hide-scrollbar">
          {statusFilters.map((filter) => (
            <button
              key={filter}
              onClick={() => setActiveFilter(filter)}
              className={`px-4 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition-colors ${
                activeFilter === filter
                  ? 'bg-[#c8956c] text-white'
                  : 'bg-secondary/50 text-muted-foreground'
              }`}
            >
              {filter}
            </button>
          ))}
        </div>
      </div>

      {/* Orders */}
      <div className="px-4 mt-4 flex flex-col gap-3">
        {filteredOrders.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 gap-3">
            <div className="w-20 h-20 rounded-2xl bg-secondary/50 flex items-center justify-center">
              <Package className="w-10 h-10 text-muted-foreground" />
            </div>
            <p className="text-muted-foreground font-medium">No orders found</p>
          </div>
        ) : (
          filteredOrders.map((order, i) => {
            const config = statusConfig[order.status] || statusConfig.pending;
            const StatusIcon = config.icon;
            return (
              <motion.div
                key={order.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                className="bg-card rounded-2xl card-shadow p-4"
              >
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <p className="font-bold text-sm text-foreground">{order.id}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{order.date}</p>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-xs font-semibold flex items-center gap-1 ${config.color}`}>
                    <StatusIcon className="w-3 h-3" /> {config.label}
                  </span>
                </div>

                {/* Progress for shipped */}
                {order.status === 'shipped' && (
                  <div className="flex items-center gap-2 mb-3 py-2">
                    {['Placed', 'Shipped', 'Out for Delivery', 'Delivered'].map((step, j) => (
                      <div key={step} className="flex items-center flex-1">
                        <div className={`w-2.5 h-2.5 rounded-full ${j <= 1 ? 'bg-[#c8956c]' : 'bg-border'}`} />
                        {j < 3 && <div className={`flex-1 h-0.5 ${j < 1 ? 'bg-[#c8956c]' : 'bg-border'}`} />}
                      </div>
                    ))}
                  </div>
                )}

                <div className="flex items-center justify-between pt-2 border-t border-border/30">
                  <span className="text-sm font-bold text-foreground">${order.total.toFixed(2)}</span>
                  <motion.button
                    whileTap={{ scale: 0.95 }}
                    onClick={() => navigateTo('home')}
                    className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-[#c8956c] to-[#d4a574] text-white text-xs font-semibold flex items-center gap-1"
                  >
                    <RotateCcw className="w-3 h-3" /> Reorder
                  </motion.button>
                </div>
              </motion.div>
            );
          })
        )}
      </div>
    </div>
  );
}
