'use client';

import { motion } from 'framer-motion';
import { useEffect, useState } from 'react';
import { useAppStore } from '@/store/useAppStore';
import { ShoppingBag } from 'lucide-react';

function Particle({ delay, x }: { delay: number; x: number }) {
  return (
    <motion.div
      className="absolute w-1 h-1 rounded-full bg-[#c8956c]/40"
      style={{ left: `${x}%`, bottom: '10%' }}
      initial={{ opacity: 0, y: 0 }}
      animate={{
        opacity: [0, 0.8, 0],
        y: [0, -200, -400],
      }}
      transition={{
        duration: 4,
        delay,
        repeat: Infinity,
        ease: 'easeOut',
      }}
    />
  );
}

export default function SplashScreen() {
  const { navigateTo, onboardingCompleted } = useAppStore();
  const [showShimmer, setShowShimmer] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setShowShimmer(true), 600);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => {
      navigateTo(onboardingCompleted ? 'home' : 'onboarding');
    }, 2500);
    return () => clearTimeout(timer);
  }, [navigateTo, onboardingCompleted]);

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-gradient-to-br from-[#faf9f7] via-[#f5f0eb] to-[#ede4d8] dark:from-[#0d0d12] dark:via-[#151520] dark:to-[#1a1a2e]">
      {/* Floating decorative circles */}
      {[...Array(6)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute rounded-full"
          style={{
            width: 60 + i * 40,
            height: 60 + i * 40,
            background: `radial-gradient(circle, rgba(200,149,108,${0.08 - i * 0.01}) 0%, transparent 70%)`,
            top: `${15 + i * 12}%`,
            left: `${10 + i * 15}%`,
          }}
          animate={{
            y: [0, -20, 0],
            x: [0, 10, 0],
            scale: [1, 1.05, 1],
          }}
          transition={{
            duration: 4 + i,
            repeat: Infinity,
            ease: 'easeInOut',
            delay: i * 0.5,
          }}
        />
      ))}

      {/* Particle effect */}
      {[...Array(12)].map((_, i) => (
        <Particle key={i} delay={i * 0.3} x={10 + i * 7} />
      ))}

      <div className="flex flex-col items-center gap-6 z-10">
        {/* 3D floating shopping bag */}
        <motion.div
          initial={{ scale: 0, rotate: -20 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ type: 'spring', stiffness: 200, damping: 15, delay: 0.2 }}
        >
          <motion.div
            animate={{
              y: [0, -12, 0],
              rotateY: [0, 10, 0, -10, 0],
            }}
            transition={{
              duration: 3,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
            className="relative"
          >
            {/* Pulsing radial gradient behind bag */}
            <motion.div
              className="absolute inset-0 -m-8 rounded-full"
              style={{
                background: 'radial-gradient(circle, rgba(200,149,108,0.3) 0%, transparent 70%)',
              }}
              animate={{
                scale: [1, 1.3, 1],
                opacity: [0.5, 0.8, 0.5],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: 'easeInOut',
              }}
            />
            <div className="w-24 h-24 rounded-3xl bg-gradient-to-br from-[#c8956c] to-[#d4a574] flex items-center justify-center shadow-2xl relative">
              <ShoppingBag className="w-12 h-12 text-white" strokeWidth={1.5} />
            </div>
            <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-16 h-3 bg-black/10 rounded-full blur-sm" />
          </motion.div>
        </motion.div>

        {/* Logo text with shimmer */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 0.6 }}
          className="flex flex-col items-center gap-2"
        >
          <h1 className={`text-3xl font-bold tracking-tight ${showShimmer ? 'text-shimmer' : 'text-gradient'}`}>
            Shopping Store
          </h1>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1, duration: 0.5 }}
            className="text-sm text-muted-foreground tracking-widest uppercase"
          >
            Premium Experience
          </motion.p>
        </motion.div>

        {/* Loading indicator with staggered dots */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2, duration: 0.5 }}
          className="mt-8"
        >
          <div className="w-32 h-1 rounded-full bg-muted overflow-hidden">
            <motion.div
              className="h-full bg-gradient-to-r from-[#c8956c] to-[#d4a574] rounded-full"
              initial={{ width: '0%' }}
              animate={{ width: '100%' }}
              transition={{ delay: 1.2, duration: 1.3, ease: 'easeInOut' }}
            />
          </div>
        </motion.div>
      </div>
    </div>
  );
}
