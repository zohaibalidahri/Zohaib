'use client';

import { motion, AnimatePresence } from 'framer-motion';
import { useState } from 'react';
import { useAppStore } from '@/store/useAppStore';
import { ArrowLeft, Mail, Lock, User, Eye, EyeOff } from 'lucide-react';
import { toast } from 'sonner';

export default function AuthScreen() {
  const { navigateTo, goBack } = useAppStore();
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const [loginForm, setLoginForm] = useState({ email: '', password: '' });
  const [registerForm, setRegisterForm] = useState({ name: '', email: '', password: '', confirmPassword: '' });

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    await new Promise((r) => setTimeout(r, 1500));
    setIsLoading(false);
    toast('Welcome back!', { description: 'You have logged in successfully' });
    navigateTo('home');
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (registerForm.password !== registerForm.confirmPassword) {
      toast('Passwords do not match');
      return;
    }
    setIsLoading(true);
    await new Promise((r) => setTimeout(r, 1500));
    setIsLoading(false);
    toast('Account created!', { description: 'Welcome to Shopping Store' });
    navigateTo('home');
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <div className="px-4 py-3">
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={goBack}
          className="w-10 h-10 rounded-xl bg-secondary/50 flex items-center justify-center"
        >
          <ArrowLeft className="w-5 h-5 text-foreground" />
        </motion.button>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center px-6 pb-8">
        {/* Logo */}
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="mb-8"
        >
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#c8956c] to-[#d4a574] flex items-center justify-center shadow-xl">
            <span className="text-white text-xl font-bold">S</span>
          </div>
        </motion.div>

        {/* Mode Toggle */}
        <div className="flex w-full max-w-sm bg-secondary/30 rounded-xl p-1 mb-6">
          {(['login', 'register'] as const).map((m) => (
            <button
              key={m}
              onClick={() => setMode(m)}
              className={`flex-1 py-2.5 rounded-lg text-sm font-semibold capitalize transition-colors ${
                mode === m ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground'
              }`}
            >
              {m}
            </button>
          ))}
        </div>

        {/* Form */}
        <AnimatePresence mode="wait">
          {mode === 'login' ? (
            <motion.form
              key="login"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              onSubmit={handleLogin}
              className="w-full max-w-sm flex flex-col gap-4"
            >
              <div className="flex items-center gap-3 px-4 py-3 rounded-xl bg-secondary/30 border border-border/30">
                <Mail className="w-4 h-4 text-muted-foreground" />
                <input
                  type="email"
                  value={loginForm.email}
                  onChange={(e) => setLoginForm({ ...loginForm, email: e.target.value })}
                  placeholder="Email address"
                  className="flex-1 bg-transparent text-sm text-foreground outline-none placeholder:text-muted-foreground"
                  required
                />
              </div>
              <div className="flex items-center gap-3 px-4 py-3 rounded-xl bg-secondary/30 border border-border/30">
                <Lock className="w-4 h-4 text-muted-foreground" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={loginForm.password}
                  onChange={(e) => setLoginForm({ ...loginForm, password: e.target.value })}
                  placeholder="Password"
                  className="flex-1 bg-transparent text-sm text-foreground outline-none placeholder:text-muted-foreground"
                  required
                />
                <button type="button" onClick={() => setShowPassword(!showPassword)}>
                  {showPassword ? <EyeOff className="w-4 h-4 text-muted-foreground" /> : <Eye className="w-4 h-4 text-muted-foreground" />}
                </button>
              </div>
              <div className="flex justify-end">
                <button type="button" className="text-xs text-[#c8956c] dark:text-[#d4a574] font-medium">Forgot Password?</button>
              </div>
              <motion.button
                type="submit"
                whileTap={{ scale: 0.97 }}
                disabled={isLoading}
                className="w-full h-12 rounded-xl bg-gradient-to-r from-[#c8956c] to-[#d4a574] text-white font-semibold text-sm disabled:opacity-60"
              >
                {isLoading ? 'Signing in...' : 'Sign In'}
              </motion.button>
            </motion.form>
          ) : (
            <motion.form
              key="register"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              onSubmit={handleRegister}
              className="w-full max-w-sm flex flex-col gap-4"
            >
              <div className="flex items-center gap-3 px-4 py-3 rounded-xl bg-secondary/30 border border-border/30">
                <User className="w-4 h-4 text-muted-foreground" />
                <input
                  type="text"
                  value={registerForm.name}
                  onChange={(e) => setRegisterForm({ ...registerForm, name: e.target.value })}
                  placeholder="Full name"
                  className="flex-1 bg-transparent text-sm text-foreground outline-none placeholder:text-muted-foreground"
                  required
                />
              </div>
              <div className="flex items-center gap-3 px-4 py-3 rounded-xl bg-secondary/30 border border-border/30">
                <Mail className="w-4 h-4 text-muted-foreground" />
                <input
                  type="email"
                  value={registerForm.email}
                  onChange={(e) => setRegisterForm({ ...registerForm, email: e.target.value })}
                  placeholder="Email address"
                  className="flex-1 bg-transparent text-sm text-foreground outline-none placeholder:text-muted-foreground"
                  required
                />
              </div>
              <div className="flex items-center gap-3 px-4 py-3 rounded-xl bg-secondary/30 border border-border/30">
                <Lock className="w-4 h-4 text-muted-foreground" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={registerForm.password}
                  onChange={(e) => setRegisterForm({ ...registerForm, password: e.target.value })}
                  placeholder="Password"
                  className="flex-1 bg-transparent text-sm text-foreground outline-none placeholder:text-muted-foreground"
                  required
                />
                <button type="button" onClick={() => setShowPassword(!showPassword)}>
                  {showPassword ? <EyeOff className="w-4 h-4 text-muted-foreground" /> : <Eye className="w-4 h-4 text-muted-foreground" />}
                </button>
              </div>
              <div className="flex items-center gap-3 px-4 py-3 rounded-xl bg-secondary/30 border border-border/30">
                <Lock className="w-4 h-4 text-muted-foreground" />
                <input
                  type="password"
                  value={registerForm.confirmPassword}
                  onChange={(e) => setRegisterForm({ ...registerForm, confirmPassword: e.target.value })}
                  placeholder="Confirm password"
                  className="flex-1 bg-transparent text-sm text-foreground outline-none placeholder:text-muted-foreground"
                  required
                />
              </div>
              <motion.button
                type="submit"
                whileTap={{ scale: 0.97 }}
                disabled={isLoading}
                className="w-full h-12 rounded-xl bg-gradient-to-r from-[#c8956c] to-[#d4a574] text-white font-semibold text-sm disabled:opacity-60"
              >
                {isLoading ? 'Creating account...' : 'Create Account'}
              </motion.button>
            </motion.form>
          )}
        </AnimatePresence>

        {/* Divider */}
        <div className="flex items-center gap-4 my-6 w-full max-w-sm">
          <div className="flex-1 h-px bg-border/50" />
          <span className="text-xs text-muted-foreground">or</span>
          <div className="flex-1 h-px bg-border/50" />
        </div>

        {/* Social Login */}
        <div className="w-full max-w-sm flex flex-col gap-3">
          <motion.button
            whileTap={{ scale: 0.97 }}
            className="w-full h-12 rounded-xl bg-secondary/30 border border-border/30 text-foreground font-medium text-sm flex items-center justify-center gap-2"
          >
            <span className="text-lg">G</span> Continue with Google
          </motion.button>
          <motion.button
            whileTap={{ scale: 0.97 }}
            onClick={() => { toast('Continuing as guest'); navigateTo('home'); }}
            className="w-full h-12 rounded-xl border border-border/30 text-muted-foreground font-medium text-sm"
          >
            Continue as Guest
          </motion.button>
        </div>
      </div>
    </div>
  );
}
