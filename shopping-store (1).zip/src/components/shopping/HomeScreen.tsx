'use client';

import { motion, AnimatePresence } from 'framer-motion';
import React, { useState, useEffect, useCallback } from 'react';
import { useAppStore } from '@/store/useAppStore';
import { products, getFeaturedProducts, getTrendingProducts, getNewArrivals } from '@/data/products';
import { categories } from '@/data/categories';
import ProductCard from './ProductCard';
import {
  Bell, Moon, Sun, Search, ChevronRight, Zap, Clock,
  Tag, Sparkles, TrendingUp, Award, ArrowRight, Ticket,
  Smartphone, Shirt, Home as HomeIcon, Sparkles as SparklesIcon, Dumbbell, BookOpen, Gamepad2, ShoppingBasket, Gem, Car, Flower2, Music
} from 'lucide-react';
import { getCategoryByName } from '@/data/categories';
import { ProductCardSkeleton, BannerSkeleton, CategorySkeleton } from './SkeletonLoader';

const catIconMap: Record<string, React.ComponentType<{className?: string}>> = {
  Smartphone, Shirt, Home: HomeIcon, Sparkles: SparklesIcon, Dumbbell, BookOpen, Gamepad2, ShoppingBasket, Gem, Car, Flower2, Music,
};

function FlashSaleTimer() {
  const [time, setTime] = useState({ hours: 5, minutes: 42, seconds: 18 });

  useEffect(() => {
    const timer = setInterval(() => {
      setTime((prev) => {
        let { hours, minutes, seconds } = prev;
        seconds--;
        if (seconds < 0) { seconds = 59; minutes--; }
        if (minutes < 0) { minutes = 59; hours--; }
        if (hours < 0) { hours = 23; minutes = 59; seconds = 59; }
        return { hours, minutes, seconds };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="flex items-center gap-1">
      {[time.hours, time.minutes, time.seconds].map((val, i) => (
        <div key={i} className="flex items-center gap-1">
          <motion.span
            key={val}
            initial={{ y: -4, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="w-8 h-8 rounded-lg bg-red-600 text-white text-sm font-bold flex items-center justify-center"
          >
            {String(val).padStart(2, '0')}
          </motion.span>
          {i < 2 && <span className="text-red-500 font-bold text-xs">:</span>}
        </div>
      ))}
    </div>
  );
}

export default function HomeScreen() {
  const { navigateTo, setSelectedCategory, theme, toggleTheme, selectedCategory } = useAppStore();
  const [currentBanner, setCurrentBanner] = useState(0);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setIsLoading(false), 800);
    return () => clearTimeout(timer);
  }, []);
  const flashSaleProducts = products.filter((p) => p.discount >= 30).slice(0, 6);
  const featuredProducts = getFeaturedProducts().slice(0, 8);
  const trendingProducts = getTrendingProducts();
  const newArrivals = getNewArrivals();
  const bestDeals = products.filter((p) => p.discount >= 30).slice(0, 6);
  const recommendedProducts = [...products].sort(() => Math.random() - 0.5).slice(0, 6);
  const recentlyViewed = products.slice(0, 5);

  const banners = [
    {
      title: 'Summer Collection',
      subtitle: 'Up to 50% off on trending styles',
      gradient: 'from-amber-500 to-orange-600',
      image: '/images/banners/banner-1.png',
      cta: 'Shop Now',
    },
    {
      title: 'Tech Deals Week',
      subtitle: 'Premium gadgets at unbeatable prices',
      gradient: 'from-emerald-500 to-teal-600',
      image: '/images/banners/banner-2.png',
      cta: 'Explore',
    },
    {
      title: 'Free Shipping',
      subtitle: 'On all orders above $50 this week',
      gradient: 'from-rose-500 to-pink-600',
      image: '/images/banners/banner-3.png',
      cta: 'Order Now',
    },
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentBanner((prev) => (prev + 1) % banners.length);
    }, 4000);
    return () => clearInterval(timer);
  }, [banners.length]);

  const handleCategoryTap = useCallback((catName: string) => {
    setSelectedCategory(catName);
    navigateTo('product-listing');
  }, [navigateTo, setSelectedCategory]);

  const sectionVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: { opacity: 1, y: 0 },
  };

  return (
    <div className="pb-24 min-h-screen bg-background">
      {/* Top Bar */}
      <div className="sticky top-0 z-40 glass-strong">
        <div className="flex items-center justify-between px-4 py-3">
          <h1 className="text-xl font-bold text-gradient">Shopping Store</h1>
          <div className="flex items-center gap-3">
            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={() => navigateTo('notifications')}
              className="relative w-10 h-10 rounded-xl bg-secondary/50 flex items-center justify-center"
            >
              <Bell className="w-5 h-5 text-foreground" />
              <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-red-500" />
            </motion.button>
            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={toggleTheme}
              className="w-10 h-10 rounded-xl bg-secondary/50 flex items-center justify-center"
            >
              {theme === 'light' ? <Moon className="w-5 h-5 text-foreground" /> : <Sun className="w-5 h-5 text-foreground" />}
            </motion.button>
          </div>
        </div>
      </div>

      <div className="px-4 flex flex-col gap-8 mt-4">
        {/* Search Bar */}
        <motion.button
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => navigateTo('search')}
          className="flex items-center gap-3 px-4 py-3 rounded-2xl bg-secondary/50 border border-border/50"
        >
          <Search className="w-5 h-5 text-muted-foreground" />
          <span className="text-muted-foreground text-sm">Search products, brands...</span>
        </motion.button>

        {isLoading ? (
          <div className="flex flex-col gap-8">
            <BannerSkeleton />
            <CategorySkeleton />
            <div className="grid grid-cols-2 gap-3">
              {[...Array(4)].map((_, i) => (
                <ProductCardSkeleton key={i} />
              ))}
            </div>
          </div>
        ) : (
        <>
        {/* Hero Banner Carousel */}
        <motion.div
          initial="hidden"
          animate="visible"
          variants={sectionVariants}
          transition={{ duration: 0.4 }}
          className="relative overflow-hidden rounded-2xl"
        >
          <AnimatePresence mode="wait">
            <motion.div
              key={currentBanner}
              initial={{ opacity: 0, x: 100 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -100 }}
              transition={{ duration: 0.4 }}
              className="relative h-44 sm:h-52 rounded-2xl overflow-hidden"
            >
              <img
                src={banners[currentBanner].image}
                alt={banners[currentBanner].title}
                className="absolute inset-0 w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-black/50 via-black/30 to-transparent" />
              <div className="relative z-10 h-full p-6 flex flex-col justify-between">
                <div>
                  <h2 className="text-xl sm:text-2xl font-bold text-white">{banners[currentBanner].title}</h2>
                  <p className="text-white/80 text-sm mt-1">{banners[currentBanner].subtitle}</p>
                </div>
                <motion.button
                  whileTap={{ scale: 0.95 }}
                  className="self-start px-5 py-2 rounded-xl bg-white/20 backdrop-blur-sm text-white text-sm font-semibold flex items-center gap-1"
                >
                  {banners[currentBanner].cta} <ArrowRight className="w-4 h-4" />
                </motion.button>
              </div>
            </motion.div>
          </AnimatePresence>
          {/* Dot indicators */}
          <div className="flex justify-center gap-1.5 mt-3">
            {banners.map((_, i) => (
              <motion.div
                key={i}
                className="h-1.5 rounded-full"
                animate={{
                  width: i === currentBanner ? 24 : 8,
                  backgroundColor: i === currentBanner ? '#c8956c' : '#e8e0d8',
                }}
                transition={{ duration: 0.3 }}
              />
            ))}
          </div>
        </motion.div>

        {/* Category Chips */}
        <motion.div
          initial="hidden"
          animate="visible"
          variants={sectionVariants}
          transition={{ duration: 0.4, delay: 0.1 }}
        >
          <div className="flex gap-3 overflow-x-auto hide-scrollbar pb-1">
            {categories.slice(0, 8).map((cat, i) => {
              const catIcon = cat.icon;
              return (
                <motion.button
                  key={cat.id}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => handleCategoryTap(cat.name)}
                  className="flex flex-col items-center gap-1.5 min-w-[72px]"
                >
                  <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${cat.gradient} flex items-center justify-center shadow-md`}>
                    {(() => { const IconComp = catIconMap[catIcon]; return IconComp ? <IconComp className="w-7 h-7 text-white" /> : null; })()}
                  </div>
                  <span className="text-[10px] text-muted-foreground font-medium whitespace-nowrap">{cat.name}</span>
                </motion.button>
              );
            })}
          </div>
        </motion.div>

        {/* Flash Sale Section */}
        <motion.div
          initial="hidden"
          animate="visible"
          variants={sectionVariants}
          transition={{ duration: 0.4, delay: 0.15 }}
        >
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-red-500" />
              <h2 className="text-lg font-bold text-foreground">Flash Sale</h2>
            </div>
            <FlashSaleTimer />
          </div>
          <div className="flex gap-3 overflow-x-auto hide-scrollbar">
            {flashSaleProducts.map((product, i) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: i * 0.05 }}
                className="min-w-[140px]"
              >
                <div
                  onClick={() => {
                    useAppStore.getState().setSelectedProductId(product.id);
                    navigateTo('product-detail');
                  }}
                  className="bg-card rounded-2xl card-shadow overflow-hidden cursor-pointer"
                >
                  <div className="relative aspect-square overflow-hidden">
                    <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
                    <div className="absolute top-1 left-1 px-1.5 py-0.5 rounded-md bg-red-500 text-white text-[9px] font-bold">
                      -{product.discount}%
                    </div>
                  </div>
                  <div className="p-2">
                    <p className="text-xs font-medium text-foreground line-clamp-1">{product.name}</p>
                    <div className="flex items-center gap-1 mt-1">
                      <span className="text-sm font-bold text-foreground">${product.price}</span>
                      <span className="text-[10px] text-muted-foreground line-through">${product.originalPrice}</span>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Featured Products */}
        <motion.div
          initial="hidden"
          animate="visible"
          variants={sectionVariants}
          transition={{ duration: 0.4, delay: 0.2 }}
        >
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Award className="w-5 h-5 text-[#c8956c]" />
              <h2 className="text-lg font-bold text-foreground">Featured</h2>
            </div>
            <button
              onClick={() => {
                setSelectedCategory(null);
                navigateTo('product-listing');
              }}
              className="flex items-center gap-1 text-sm text-[#c8956c] dark:text-[#d4a574] font-medium"
            >
              See All <ChevronRight className="w-4 h-4" />
            </button>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {featuredProducts.slice(0, 6).map((product, i) => (
              <ProductCard key={product.id} product={product} index={i} />
            ))}
          </div>
        </motion.div>

        {/* Coupon Banner */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="relative rounded-2xl overflow-hidden"
        >
          <div className="bg-gradient-to-r from-[#c8956c] to-[#d4a574] p-5 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Ticket className="w-8 h-8 text-white" />
              <div>
                <p className="text-white font-bold text-sm">Use Code: SAVE20</p>
                <p className="text-white/80 text-xs">Get 20% off on your first order</p>
              </div>
            </div>
            <motion.button
              whileTap={{ scale: 0.95 }}
              className="px-4 py-2 rounded-xl bg-white/20 text-white text-xs font-semibold backdrop-blur-sm"
            >
              Copy
            </motion.button>
          </div>
        </motion.div>

        {/* Featured Brands */}
        <motion.div
          initial="hidden"
          animate="visible"
          variants={sectionVariants}
          transition={{ duration: 0.4, delay: 0.28 }}
        >
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-lg font-bold text-foreground">Featured Brands</h2>
          </div>
          <div className="flex gap-3 overflow-x-auto hide-scrollbar">
            {[
              { name: 'Aura', gradient: 'from-rose-400 to-pink-500' },
              { name: 'Vertex', gradient: 'from-violet-400 to-purple-500' },
              { name: 'Luxe', gradient: 'from-amber-400 to-yellow-500' },
              { name: 'Nova', gradient: 'from-emerald-400 to-teal-500' },
              { name: 'Zephyr', gradient: 'from-sky-400 to-blue-500' },
              { name: 'Prism', gradient: 'from-fuchsia-400 to-pink-500' },
            ].map((brand, i) => (
              <motion.div
                key={brand.name}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: i * 0.05 }}
                whileTap={{ scale: 0.95 }}
                className="min-w-[100px] flex flex-col items-center gap-2 cursor-pointer"
              >
                <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${brand.gradient} flex items-center justify-center shadow-lg`}>
                  <span className="text-white text-lg font-bold">{brand.name[0]}</span>
                </div>
                <span className="text-xs font-medium text-muted-foreground">{brand.name}</span>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Trending Now */}
        <motion.div
          initial="hidden"
          animate="visible"
          variants={sectionVariants}
          transition={{ duration: 0.4, delay: 0.25 }}
        >
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-orange-500" />
              <h2 className="text-lg font-bold text-foreground">Trending Now</h2>
            </div>
            <button
              onClick={() => navigateTo('product-listing')}
              className="flex items-center gap-1 text-sm text-[#c8956c] dark:text-[#d4a574] font-medium"
            >
              See All <ChevronRight className="w-4 h-4" />
            </button>
          </div>
          <div className="flex gap-3 overflow-x-auto hide-scrollbar">
            {trendingProducts.map((product, i) => (
              <div key={product.id} className="min-w-[160px]">
                <ProductCard product={product} index={i} />
              </div>
            ))}
          </div>
        </motion.div>

        {/* Best Deals */}
        <motion.div
          initial="hidden"
          animate="visible"
          variants={sectionVariants}
          transition={{ duration: 0.4, delay: 0.3 }}
        >
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Tag className="w-5 h-5 text-emerald-500" />
              <h2 className="text-lg font-bold text-foreground">Best Deals</h2>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {bestDeals.slice(0, 4).map((product, i) => (
              <ProductCard key={product.id} product={product} index={i} />
            ))}
          </div>
        </motion.div>

        {/* New Arrivals */}
        <motion.div
          initial="hidden"
          animate="visible"
          variants={sectionVariants}
          transition={{ duration: 0.4, delay: 0.35 }}
        >
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-500" />
              <h2 className="text-lg font-bold text-foreground">New Arrivals</h2>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {newArrivals.slice(0, 4).map((product, i) => (
              <ProductCard key={product.id} product={product} index={i} />
            ))}
          </div>
        </motion.div>

        {/* Recommended For You */}
        <motion.div
          initial="hidden"
          animate="visible"
          variants={sectionVariants}
          transition={{ duration: 0.4, delay: 0.4 }}
        >
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-lg font-bold text-foreground">Recommended For You</h2>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {recommendedProducts.slice(0, 4).map((product, i) => (
              <ProductCard key={product.id} product={product} index={i} />
            ))}
          </div>
        </motion.div>

        {/* Recently Viewed */}
        <motion.div
          initial="hidden"
          animate="visible"
          variants={sectionVariants}
          transition={{ duration: 0.4, delay: 0.45 }}
        >
          <div className="flex items-center justify-between mb-3">
            <Clock className="w-5 h-5 text-muted-foreground" />
            <h2 className="text-lg font-bold text-foreground">Recently Viewed</h2>
          </div>
          <div className="flex gap-3 overflow-x-auto hide-scrollbar">
            {recentlyViewed.map((product, i) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: i * 0.05 }}
                className="min-w-[120px]"
                onClick={() => {
                  useAppStore.getState().setSelectedProductId(product.id);
                  navigateTo('product-detail');
                }}
              >
                <div className="bg-card rounded-2xl card-shadow overflow-hidden cursor-pointer">
                  <div className="aspect-square overflow-hidden">
                    <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
                  </div>
                  <div className="p-2">
                    <p className="text-xs font-medium text-foreground line-clamp-1">{product.name}</p>
                    <p className="text-xs font-bold text-foreground mt-0.5">${product.price}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
        </>
        )}
      </div>
    </div>
  );
}
