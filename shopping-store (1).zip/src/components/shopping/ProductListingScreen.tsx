'use client';

import { motion, AnimatePresence } from 'framer-motion';
import { useState, useMemo } from 'react';
import { useAppStore } from '@/store/useAppStore';
import { products, getProductsByCategory } from '@/data/products';
import ProductCard from './ProductCard';
import { ArrowLeft, LayoutGrid, List, SlidersHorizontal, X } from 'lucide-react';

export default function ProductListingScreen() {
  const { selectedCategory, navigateTo, goBack } = useAppStore();
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [showFilter, setShowFilter] = useState(false);
  const [sortBy, setSortBy] = useState('popular');
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 500]);
  const [minRating, setMinRating] = useState(0);
  const [inStockOnly, setInStockOnly] = useState(false);
  const [discountOnly, setDiscountOnly] = useState(false);

  const categoryProducts = useMemo(() => {
    let filtered = selectedCategory
      ? getProductsByCategory(selectedCategory)
      : products;

    // Apply filters
    filtered = filtered.filter((p) => {
      if (p.price < priceRange[0] || p.price > priceRange[1]) return false;
      if (minRating > 0 && p.rating < minRating) return false;
      if (inStockOnly && !p.inStock) return false;
      if (discountOnly && p.discount === 0) return false;
      return true;
    });

    // Apply sort
    switch (sortBy) {
      case 'price-low':
        return [...filtered].sort((a, b) => a.price - b.price);
      case 'price-high':
        return [...filtered].sort((a, b) => b.price - a.price);
      case 'rating':
        return [...filtered].sort((a, b) => b.rating - a.rating);
      case 'newest':
        return [...filtered].sort((a, b) => (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0));
      default:
        return [...filtered].sort((a, b) => b.reviewCount - a.reviewCount);
    }
  }, [selectedCategory, sortBy, priceRange, minRating, inStockOnly, discountOnly]);

  const resetFilters = () => {
    setPriceRange([0, 500]);
    setMinRating(0);
    setInStockOnly(false);
    setDiscountOnly(false);
    setSortBy('popular');
  };

  return (
    <div className="pb-24 min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-40 glass-strong">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={goBack}
              className="w-10 h-10 rounded-xl bg-secondary/50 flex items-center justify-center"
            >
              <ArrowLeft className="w-5 h-5 text-foreground" />
            </motion.button>
            <div>
              <h1 className="text-lg font-bold text-foreground">{selectedCategory || 'All Products'}</h1>
              <p className="text-xs text-muted-foreground">{categoryProducts.length} products</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={() => setViewMode(viewMode === 'grid' ? 'list' : 'grid')}
              className="w-10 h-10 rounded-xl bg-secondary/50 flex items-center justify-center"
            >
              {viewMode === 'grid' ? <List className="w-5 h-5 text-foreground" /> : <LayoutGrid className="w-5 h-5 text-foreground" />}
            </motion.button>
            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={() => setShowFilter(!showFilter)}
              className="w-10 h-10 rounded-xl bg-secondary/50 flex items-center justify-center"
            >
              <SlidersHorizontal className="w-5 h-5 text-foreground" />
            </motion.button>
          </div>
        </div>

        {/* Sort options */}
        <div className="flex gap-2 px-4 pb-3 overflow-x-auto hide-scrollbar">
          {[
            { key: 'popular', label: 'Popular' },
            { key: 'price-low', label: 'Price: Low-High' },
            { key: 'price-high', label: 'Price: High-Low' },
            { key: 'rating', label: 'Rating' },
            { key: 'newest', label: 'Newest' },
          ].map((opt) => (
            <button
              key={opt.key}
              onClick={() => setSortBy(opt.key)}
              className={`px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition-colors ${
                sortBy === opt.key
                  ? 'bg-[#c8956c] text-white'
                  : 'bg-secondary/50 text-muted-foreground'
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>
      </div>

      {/* Products */}
      <div className="px-4 mt-4">
        {viewMode === 'grid' ? (
          <div className="grid grid-cols-2 gap-3">
            {categoryProducts.map((product, i) => (
              <ProductCard key={product.id} product={product} index={i} layout="grid" />
            ))}
          </div>
        ) : (
          <div className="flex flex-col gap-3">
            {categoryProducts.map((product, i) => (
              <ProductCard key={product.id} product={product} index={i} layout="list" />
            ))}
          </div>
        )}

        {categoryProducts.length === 0 && (
          <div className="flex flex-col items-center justify-center py-20 gap-3">
            <p className="text-4xl">🔍</p>
            <p className="text-muted-foreground font-medium">No products found</p>
            <p className="text-sm text-muted-foreground">Try adjusting your filters</p>
          </div>
        )}
      </div>

      {/* Filter Panel */}
      <AnimatePresence>
        {showFilter && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/40 z-50"
              onClick={() => setShowFilter(false)}
            />
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 300 }}
              className="fixed bottom-0 left-0 right-0 z-50 bg-card rounded-t-3xl p-6 max-h-[70vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-bold text-foreground">Filters</h3>
                <motion.button
                  whileTap={{ scale: 0.9 }}
                  onClick={() => setShowFilter(false)}
                  className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center"
                >
                  <X className="w-4 h-4 text-foreground" />
                </motion.button>
              </div>

              {/* Price Range */}
              <div className="mb-6">
                <h4 className="font-semibold text-sm text-foreground mb-3">Price Range</h4>
                <div className="flex items-center gap-3">
                  <input
                    type="number"
                    value={priceRange[0]}
                    onChange={(e) => setPriceRange([Number(e.target.value), priceRange[1]])}
                    className="w-full px-3 py-2 rounded-xl bg-secondary/50 text-sm text-foreground outline-none border border-border/50"
                    placeholder="Min"
                  />
                  <span className="text-muted-foreground">-</span>
                  <input
                    type="number"
                    value={priceRange[1]}
                    onChange={(e) => setPriceRange([priceRange[0], Number(e.target.value)])}
                    className="w-full px-3 py-2 rounded-xl bg-secondary/50 text-sm text-foreground outline-none border border-border/50"
                    placeholder="Max"
                  />
                </div>
              </div>

              {/* Rating */}
              <div className="mb-6">
                <h4 className="font-semibold text-sm text-foreground mb-3">Minimum Rating</h4>
                <div className="flex gap-2">
                  {[0, 3, 3.5, 4, 4.5].map((r) => (
                    <button
                      key={r}
                      onClick={() => setMinRating(r)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-medium ${
                        minRating === r
                          ? 'bg-[#c8956c] text-white'
                          : 'bg-secondary/50 text-muted-foreground'
                      }`}
                    >
                      {r === 0 ? 'All' : `${r}+`}
                    </button>
                  ))}
                </div>
              </div>

              {/* Toggles */}
              <div className="mb-6 flex flex-col gap-3">
                <label className="flex items-center justify-between">
                  <span className="text-sm text-foreground">In Stock Only</span>
                  <button
                    onClick={() => setInStockOnly(!inStockOnly)}
                    className={`w-12 h-6 rounded-full transition-colors ${inStockOnly ? 'bg-[#c8956c]' : 'bg-secondary'}`}
                  >
                    <div className={`w-5 h-5 rounded-full bg-white shadow-sm transition-transform ${inStockOnly ? 'translate-x-6.5' : 'translate-x-0.5'}`} />
                  </button>
                </label>
                <label className="flex items-center justify-between">
                  <span className="text-sm text-foreground">Discount Only</span>
                  <button
                    onClick={() => setDiscountOnly(!discountOnly)}
                    className={`w-12 h-6 rounded-full transition-colors ${discountOnly ? 'bg-[#c8956c]' : 'bg-secondary'}`}
                  >
                    <div className={`w-5 h-5 rounded-full bg-white shadow-sm transition-transform ${discountOnly ? 'translate-x-6.5' : 'translate-x-0.5'}`} />
                  </button>
                </label>
              </div>

              {/* Buttons */}
              <div className="flex gap-3">
                <button
                  onClick={resetFilters}
                  className="flex-1 py-3 rounded-2xl bg-secondary text-foreground font-semibold text-sm"
                >
                  Reset
                </button>
                <button
                  onClick={() => setShowFilter(false)}
                  className="flex-1 py-3 rounded-2xl bg-gradient-to-r from-[#c8956c] to-[#d4a574] text-white font-semibold text-sm"
                >
                  Apply
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
