'use client';

import { motion } from 'framer-motion';

export function ProductCardSkeleton() {
  return (
    <div className="bg-card rounded-2xl overflow-hidden">
      <div className="aspect-square skeleton" />
      <div className="p-3 flex flex-col gap-2">
        <div className="h-4 w-3/4 rounded-lg skeleton" />
        <div className="h-3 w-1/2 rounded-lg skeleton" />
        <div className="flex items-center justify-between">
          <div className="h-5 w-16 rounded-lg skeleton" />
          <div className="h-8 w-8 rounded-xl skeleton" />
        </div>
      </div>
    </div>
  );
}

export function BannerSkeleton() {
  return (
    <div className="h-44 sm:h-52 rounded-2xl skeleton" />
  );
}

export function CategorySkeleton() {
  return (
    <div className="flex gap-3 overflow-hidden">
      {[...Array(6)].map((_, i) => (
        <div key={i} className="flex flex-col items-center gap-1.5 min-w-[72px]">
          <div className="w-14 h-14 rounded-2xl skeleton" />
          <div className="h-3 w-12 rounded skeleton" />
        </div>
      ))}
    </div>
  );
}

export function CartItemSkeleton() {
  return (
    <div className="flex gap-3 p-3 bg-card rounded-2xl">
      <div className="w-20 h-20 rounded-xl skeleton" />
      <div className="flex-1 flex flex-col gap-2">
        <div className="h-4 w-3/4 rounded-lg skeleton" />
        <div className="h-3 w-1/2 rounded-lg skeleton" />
        <div className="flex justify-between">
          <div className="h-5 w-20 rounded-lg skeleton" />
          <div className="h-7 w-7 rounded-lg skeleton" />
        </div>
      </div>
    </div>
  );
}
