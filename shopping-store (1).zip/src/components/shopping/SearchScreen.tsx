'use client';

import { motion } from 'framer-motion';
import { useState, useMemo, useCallback } from 'react';
import { useAppStore } from '@/store/useAppStore';
import { searchProducts } from '@/data/products';
import { categories } from '@/data/categories';
import ProductCard from './ProductCard';
import { Search, X, Clock, TrendingUp } from 'lucide-react';

export default function SearchScreen() {
  const { searchQuery, setSearchQuery, recentSearches, addRecentSearch, clearRecentSearches, navigateTo, setSelectedCategory, goBack } = useAppStore();
  const [localQuery, setLocalQuery] = useState(searchQuery);

  const popularSearches = ['Wireless earbuds', 'Running shoes', 'Smart watch', 'Leather bag', 'Coffee maker', 'Yoga mat', 'Face serum', 'Desk lamp'];

  const results = useMemo(() => {
    if (!localQuery.trim()) return [];
    return searchProducts(localQuery);
  }, [localQuery]);

  const handleSearch = useCallback((q: string) => {
    setLocalQuery(q);
    if (q.trim()) {
      addRecentSearch(q.trim());
    }
  }, [addRecentSearch]);

  return (
    <div className="pb-24 min-h-screen bg-background">
      {/* Search Header */}
      <div className="sticky top-0 z-40 glass-strong">
        <div className="flex items-center gap-3 px-4 py-3">
          <div className="flex-1 flex items-center gap-3 px-4 py-2.5 rounded-2xl bg-secondary/50 border border-border/50">
            <Search className="w-4 h-4 text-muted-foreground" />
            <input
              type="text"
              value={localQuery}
              onChange={(e) => handleSearch(e.target.value)}
              placeholder="Search products, brands..."
              autoFocus
              className="flex-1 bg-transparent text-sm text-foreground outline-none placeholder:text-muted-foreground"
            />
            {localQuery && (
              <motion.button
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => { setLocalQuery(''); setSearchQuery(''); }}
                className="w-5 h-5 rounded-full bg-muted-foreground/20 flex items-center justify-center"
              >
                <X className="w-3 h-3 text-foreground" />
              </motion.button>
            )}
          </div>
          <button onClick={goBack} className="text-sm text-[#c8956c] dark:text-[#d4a574] font-medium">
            Cancel
          </button>
        </div>
      </div>

      <div className="px-4 mt-4">
        {/* Search Results */}
        {localQuery.trim() && (
          <div>
            {results.length > 0 ? (
              <div>
                <p className="text-sm text-muted-foreground mb-3">{results.length} results for &ldquo;{localQuery}&rdquo;</p>
                <div className="grid grid-cols-2 gap-3">
                  {results.map((product, i) => (
                    <ProductCard key={product.id} product={product} index={i} />
                  ))}
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-16 gap-3">
                <p className="text-4xl">🔍</p>
                <p className="text-muted-foreground font-medium">No results found</p>
                <p className="text-sm text-muted-foreground">Try different keywords</p>
              </div>
            )}
          </div>
        )}

        {/* Default state (no query) */}
        {!localQuery.trim() && (
          <div className="flex flex-col gap-6">
            {/* Recent Searches */}
            {recentSearches.length > 0 && (
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-muted-foreground" />
                    <h3 className="font-semibold text-sm text-foreground">Recent Searches</h3>
                  </div>
                  <button onClick={clearRecentSearches} className="text-xs text-[#c8956c] dark:text-[#d4a574] font-medium">
                    Clear All
                  </button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {recentSearches.map((q) => (
                    <motion.button
                      key={q}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => handleSearch(q)}
                      className="px-3 py-1.5 rounded-xl bg-secondary/50 text-sm text-foreground"
                    >
                      {q}
                    </motion.button>
                  ))}
                </div>
              </div>
            )}

            {/* Popular Searches */}
            <div>
              <div className="flex items-center gap-2 mb-3">
                <TrendingUp className="w-4 h-4 text-muted-foreground" />
                <h3 className="font-semibold text-sm text-foreground">Popular Searches</h3>
              </div>
              <div className="flex flex-wrap gap-2">
                {popularSearches.map((q) => (
                  <motion.button
                    key={q}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => handleSearch(q)}
                    className="px-3 py-1.5 rounded-xl bg-secondary/50 text-sm text-foreground"
                  >
                    {q}
                  </motion.button>
                ))}
              </div>
            </div>

            {/* Category Quick Links */}
            <div>
              <h3 className="font-semibold text-sm text-foreground mb-3">Browse Categories</h3>
              <div className="grid grid-cols-2 gap-2">
                {categories.slice(0, 8).map((cat) => (
                  <motion.button
                    key={cat.id}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => {
                      setSelectedCategory(cat.name);
                      navigateTo('product-listing');
                    }}
                    className={`p-3 rounded-xl bg-gradient-to-br ${cat.gradient} text-white text-sm font-medium text-left`}
                  >
                    {cat.name}
                  </motion.button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
