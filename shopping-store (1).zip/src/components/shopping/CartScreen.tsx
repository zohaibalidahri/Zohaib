'use client';

import { motion, AnimatePresence } from 'framer-motion';
import { useAppStore } from '@/store/useAppStore';
import { ArrowLeft, Minus, Plus, Trash2, ShoppingBag, Tag } from 'lucide-react';
import { toast } from 'sonner';
import { useState } from 'react';

export default function CartScreen() {
  const { cart, removeFromCart, updateCartQuantity, getCartTotal, navigateTo, goBack } = useAppStore();
  const [couponCode, setCouponCode] = useState('');
  const [couponApplied, setCouponApplied] = useState(false);

  const subtotal = getCartTotal();
  const discount = couponApplied ? subtotal * 0.1 : 0;
  const deliveryFee = subtotal > 50 ? 0 : 4.99;
  const tax = (subtotal - discount) * 0.08;
  const total = subtotal - discount + deliveryFee + tax;

  const handleApplyCoupon = () => {
    if (couponCode.toUpperCase() === 'SAVE20' || couponCode.toUpperCase() === 'SAVE10') {
      setCouponApplied(true);
      toast('Coupon applied!', { description: '10% discount added' });
    } else {
      toast('Invalid coupon code', { description: 'Please try a valid code' });
    }
  };

  if (cart.length === 0) {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        {/* Header */}
        <div className="sticky top-0 z-40 glass-strong">
          <div className="flex items-center gap-3 px-4 py-3">
            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={goBack}
              className="w-10 h-10 rounded-xl bg-secondary/50 flex items-center justify-center"
            >
              <ArrowLeft className="w-5 h-5 text-foreground" />
            </motion.button>
            <h1 className="text-lg font-bold text-foreground">My Cart</h1>
          </div>
        </div>
        <div className="flex-1 flex flex-col items-center justify-center gap-4 px-4">
          <motion.div
            initial={{ scale: 0.8 }}
            animate={{ scale: 1 }}
            className="w-24 h-24 rounded-3xl bg-secondary/50 flex items-center justify-center"
          >
            <ShoppingBag className="w-12 h-12 text-muted-foreground" />
          </motion.div>
          <h2 className="text-lg font-bold text-foreground">Your cart is empty</h2>
          <p className="text-sm text-muted-foreground text-center">Looks like you haven&apos;t added anything yet</p>
          <motion.button
            whileTap={{ scale: 0.97 }}
            onClick={() => navigateTo('home')}
            className="px-6 py-3 rounded-2xl bg-gradient-to-r from-[#c8956c] to-[#d4a574] text-white font-semibold text-sm"
          >
            Continue Shopping
          </motion.button>
        </div>
      </div>
    );
  }

  return (
    <div className="pb-44 min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-40 glass-strong">
        <div className="flex items-center gap-3 px-4 py-3">
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={goBack}
            className="w-10 h-10 rounded-xl bg-secondary/50 flex items-center justify-center"
          >
            <ArrowLeft className="w-5 h-5 text-foreground" />
          </motion.button>
          <h1 className="text-lg font-bold text-foreground">My Cart</h1>
          <span className="text-sm text-muted-foreground">({cart.length} items)</span>
        </div>
      </div>

      {/* Cart Items */}
      <div className="px-4 mt-4 flex flex-col gap-3">
        <AnimatePresence>
          {cart.map((item) => (
            <motion.div
              key={item.product.id}
              layout
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -100, height: 0 }}
              className="flex gap-3 p-3 bg-card rounded-2xl card-shadow"
            >
              <div className="w-20 h-20 rounded-xl flex-shrink-0 overflow-hidden">
                <img src={item.product.image} alt={item.product.name} className="w-full h-full object-cover" />
              </div>
              <div className="flex-1 flex flex-col justify-between min-w-0">
                <div>
                  <h3 className="font-semibold text-sm text-foreground line-clamp-1">{item.product.name}</h3>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    {item.selectedColor !== 'Default' && <span>{item.selectedColor}</span>}
                    {item.selectedColor !== 'Default' && item.selectedSize !== 'One Size' && <span> · </span>}
                    {item.selectedSize !== 'One Size' && <span>{item.selectedSize}</span>}
                  </p>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <motion.button
                      whileTap={{ scale: 0.85 }}
                      onClick={() => updateCartQuantity(item.product.id, item.quantity - 1)}
                      className="w-7 h-7 rounded-lg bg-secondary/50 flex items-center justify-center"
                    >
                      <Minus className="w-3 h-3 text-foreground" />
                    </motion.button>
                    <span className="text-sm font-bold text-foreground w-6 text-center">{item.quantity}</span>
                    <motion.button
                      whileTap={{ scale: 0.85 }}
                      onClick={() => updateCartQuantity(item.product.id, item.quantity + 1)}
                      className="w-7 h-7 rounded-lg bg-secondary/50 flex items-center justify-center"
                    >
                      <Plus className="w-3 h-3 text-foreground" />
                    </motion.button>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-sm text-foreground">
                      ${(item.product.price * item.quantity).toFixed(2)}
                    </span>
                    <motion.button
                      whileTap={{ scale: 0.85 }}
                      onClick={() => {
                        removeFromCart(item.product.id);
                        toast('Removed from cart', { description: item.product.name });
                      }}
                      className="w-7 h-7 rounded-lg bg-red-500/10 flex items-center justify-center"
                    >
                      <Trash2 className="w-3 h-3 text-red-500" />
                    </motion.button>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Coupon */}
      <div className="px-4 mt-4">
        <div className="flex items-center gap-2">
          <div className="flex-1 flex items-center gap-2 px-3 py-2.5 rounded-xl bg-secondary/30 border border-border/30">
            <Tag className="w-4 h-4 text-muted-foreground" />
            <input
              type="text"
              value={couponCode}
              onChange={(e) => setCouponCode(e.target.value)}
              placeholder="Enter coupon code"
              className="flex-1 bg-transparent text-sm text-foreground outline-none placeholder:text-muted-foreground"
              disabled={couponApplied}
            />
          </div>
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={handleApplyCoupon}
            disabled={couponApplied}
            className={`px-4 py-2.5 rounded-xl font-semibold text-sm ${
              couponApplied
                ? 'bg-emerald-500/10 text-emerald-500'
                : 'bg-gradient-to-r from-[#c8956c] to-[#d4a574] text-white'
            }`}
          >
            {couponApplied ? 'Applied ✓' : 'Apply'}
          </motion.button>
        </div>
      </div>

      {/* Price Summary */}
      <div className="px-4 mt-4">
        <div className="bg-card rounded-2xl card-shadow p-4 flex flex-col gap-2.5">
          <h3 className="font-bold text-foreground mb-1">Order Summary</h3>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Subtotal</span>
            <span className="text-foreground">${subtotal.toFixed(2)}</span>
          </div>
          {discount > 0 && (
            <div className="flex justify-between text-sm">
              <span className="text-emerald-500">Discount (10%)</span>
              <span className="text-emerald-500">-${discount.toFixed(2)}</span>
            </div>
          )}
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Delivery</span>
            <span className={deliveryFee === 0 ? 'text-emerald-500' : 'text-foreground'}>
              {deliveryFee === 0 ? 'Free' : `$${deliveryFee.toFixed(2)}`}
            </span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Tax (8%)</span>
            <span className="text-foreground">${tax.toFixed(2)}</span>
          </div>
          <div className="h-px bg-border/30 my-1" />
          <div className="flex justify-between">
            <span className="font-bold text-foreground">Total</span>
            <span className="font-bold text-lg text-foreground">${total.toFixed(2)}</span>
          </div>
        </div>
      </div>

      {/* Checkout Button */}
      <div className="fixed bottom-0 left-0 right-0 z-40 glass-strong p-4 pb-[calc(1rem+env(safe-area-inset-bottom))]">
        <div className="max-w-lg mx-auto">
          <motion.button
            whileTap={{ scale: 0.97 }}
            onClick={() => navigateTo('checkout')}
            className="w-full h-14 rounded-2xl bg-gradient-to-r from-[#c8956c] to-[#d4a574] text-white font-semibold text-base flex items-center justify-center gap-2"
          >
            Proceed to Checkout · ${total.toFixed(2)}
          </motion.button>
        </div>
      </div>
    </div>
  );
}
