'use client';

import { motion } from 'framer-motion';
import { Heart, Star, ShoppingCart, Zap, Award, Sparkles } from 'lucide-react';
import { Product, useAppStore } from '@/store/useAppStore';
import { toast } from 'sonner';
import { useState, useRef } from 'react';

interface ProductCardProps {
  product: Product;
  index?: number;
  layout?: 'grid' | 'list';
}

export default function ProductCard({ product, index = 0, layout = 'grid' }: ProductCardProps) {
  const { navigateTo, setSelectedProductId, toggleWishlist, wishlist, addToCart } = useAppStore();
  const isWished = wishlist.includes(product.id);
  const cardRef = useRef<HTMLDivElement>(null);
  const [tilt, setTilt] = useState({ x: 0, y: 0 });

  const handleTap = () => {
    setSelectedProductId(product.id);
    navigateTo('product-detail');
  };

  const handleWishlist = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleWishlist(product.id);
    toast(isWished ? 'Removed from wishlist' : 'Added to wishlist', {
      description: product.name,
    });
  };

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(product);
    toast('Added to cart', {
      description: product.name,
    });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width;
    const y = (e.clientY - rect.top) / rect.height;
    setTilt({
      x: (y - 0.5) * -6,
      y: (x - 0.5) * 6,
    });
  };

  const handleMouseLeave = () => {
    setTilt({ x: 0, y: 0 });
  };

  if (layout === 'list') {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: index * 0.05, duration: 0.3 }}
        whileTap={{ scale: 0.98 }}
        onClick={handleTap}
        className="flex gap-4 p-3 bg-card rounded-2xl card-shadow cursor-pointer"
      >
        <div className="w-24 h-24 rounded-xl flex-shrink-0 overflow-hidden">
          <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
        </div>
        <div className="flex-1 flex flex-col justify-between min-w-0">
          <div>
            <h3 className="font-semibold text-sm text-foreground truncate">{product.name}</h3>
            <div className="flex items-center gap-1 mt-1">
              <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
              <span className="text-xs text-muted-foreground">{product.rating}</span>
              <span className="text-xs text-muted-foreground">({product.reviewCount})</span>
            </div>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="font-bold text-foreground">${product.price}</span>
              {product.discount > 0 && (
                <span className="text-xs text-muted-foreground line-through">${product.originalPrice}</span>
              )}
            </div>
            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={handleAddToCart}
              className="w-8 h-8 rounded-lg bg-gradient-to-r from-[#c8956c] to-[#d4a574] flex items-center justify-center"
            >
              <ShoppingCart className="w-4 h-4 text-white" />
            </motion.button>
          </div>
        </div>
      </motion.div>
    );
  }

  return (
    <div style={{ perspective: '1000px' }}>
      <motion.div
        ref={cardRef}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: index * 0.05, duration: 0.3 }}
        whileTap={{ scale: 0.98 }}
        onClick={handleTap}
        onMouseMove={handleMouseMove}
        onMouseLeave={handleMouseLeave}
        style={{
          transformStyle: 'preserve-3d',
          rotateX: tilt.x,
          rotateY: tilt.y,
          transition: 'transform 0.15s ease-out',
        }}
        className="relative bg-card rounded-2xl card-shadow overflow-hidden cursor-pointer group"
      >
        {/* Image area */}
        <div className="relative aspect-square overflow-hidden">
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
          />

          {/* 3D depth gradient overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/10 via-transparent to-white/5 pointer-events-none" />

          {/* Inner glow effect */}
          <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300" style={{
            boxShadow: 'inset 0 0 30px rgba(200,149,108,0.15)',
          }} />

          {/* Discount badge */}
          {product.discount > 0 && (
            <div className="absolute top-2 left-2 px-2 py-0.5 rounded-lg bg-red-500 text-white text-[10px] font-bold">
              -{product.discount}%
            </div>
          )}

          {/* Status badges */}
          {product.isNew && (
            <div className="absolute top-2 left-2 mt-6 px-2 py-0.5 rounded-lg bg-emerald-500 text-white text-[10px] font-bold flex items-center gap-1">
              <Sparkles className="w-2.5 h-2.5" /> NEW
            </div>
          )}
          {product.isTrending && !product.isNew && (
            <div className="absolute top-2 left-2 mt-6 px-2 py-0.5 rounded-lg bg-orange-500 text-white text-[10px] font-bold flex items-center gap-1">
              <Zap className="w-2.5 h-2.5" /> HOT
            </div>
          )}
          {product.isBestSeller && !product.isNew && !product.isTrending && (
            <div className="absolute top-2 left-2 mt-6 px-2 py-0.5 rounded-lg bg-amber-500 text-white text-[10px] font-bold flex items-center gap-1">
              <Award className="w-2.5 h-2.5" /> BEST
            </div>
          )}

          {/* Wishlist button */}
          <motion.button
            whileTap={{ scale: 0.8 }}
            onClick={handleWishlist}
            className="absolute top-2 right-2 w-8 h-8 rounded-full bg-white/80 dark:bg-black/40 backdrop-blur-sm flex items-center justify-center"
          >
            <Heart
              className={`w-4 h-4 transition-colors ${isWished ? 'fill-red-500 text-red-500' : 'text-gray-600 dark:text-gray-300'}`}
            />
          </motion.button>

          {/* Low stock indicator */}
          {product.stockCount <= 5 && (
            <div className="absolute bottom-2 left-2 right-2">
              <div className="px-2 py-1 rounded-lg bg-orange-500/90 text-white text-[10px] font-medium text-center backdrop-blur-sm">
                Only {product.stockCount} left!
              </div>
            </div>
          )}
        </div>

        {/* Info */}
        <div className="p-3 flex flex-col gap-1.5">
          <h3 className="font-semibold text-sm text-foreground line-clamp-2 leading-tight min-h-[2.5rem]">
            {product.name}
          </h3>
          <div className="flex items-center gap-1">
            <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
            <span className="text-xs text-muted-foreground">{product.rating}</span>
            <span className="text-xs text-muted-foreground">({product.reviewCount})</span>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <span className="font-bold text-base text-foreground">${product.price}</span>
              {product.discount > 0 && (
                <span className="text-xs text-muted-foreground line-through">${product.originalPrice}</span>
              )}
            </div>
            <motion.button
              whileTap={{ scale: 0.85 }}
              onClick={handleAddToCart}
              className="w-8 h-8 rounded-xl bg-gradient-to-r from-[#c8956c] to-[#d4a574] flex items-center justify-center shadow-md"
            >
              <ShoppingCart className="w-4 h-4 text-white" />
            </motion.button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
