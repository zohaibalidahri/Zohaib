'use client';

import { motion } from 'framer-motion';
import { useAppStore, Screen } from '@/store/useAppStore';
import { Home, Grid3X3, Search, Heart, User, ShoppingCart } from 'lucide-react';

const tabs: { screen: Screen; icon: typeof Home; label: string }[] = [
  { screen: 'home', icon: Home, label: 'Home' },
  { screen: 'categories', icon: Grid3X3, label: 'Categories' },
  { screen: 'search', icon: Search, label: 'Search' },
  { screen: 'wishlist', icon: Heart, label: 'Wishlist' },
  { screen: 'profile', icon: User, label: 'Profile' },
];

export default function BottomNav() {
  const { currentScreen, navigateTo, wishlist, getCartCount } = useAppStore();
  const cartCount = getCartCount();

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50">
      {/* Cart FAB */}
      {cartCount > 0 && (
        <motion.div
          className="absolute -top-8 right-4 z-10"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: 'spring', stiffness: 300, damping: 20 }}
        >
          <motion.button
            whileTap={{ scale: 0.9 }}
            whileHover={{ scale: 1.05 }}
            onClick={() => navigateTo('cart')}
            className="w-14 h-14 rounded-2xl bg-gradient-to-r from-[#c8956c] to-[#d4a574] text-white flex items-center justify-center shadow-xl relative"
          >
            <ShoppingCart className="w-6 h-6" />
            <motion.span
              key={cartCount}
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center"
            >
              {cartCount}
            </motion.span>
            {/* Pulse ring animation when items in cart */}
            <motion.div
              className="absolute inset-0 rounded-2xl border-2 border-[#c8956c]"
              animate={{
                scale: [1, 1.15, 1],
                opacity: [0.6, 0, 0.6],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: 'easeInOut',
              }}
            />
          </motion.button>
        </motion.div>
      )}

      {/* Nav bar */}
      <div className="glass-strong">
        <div className="flex items-center justify-around px-2 pb-[env(safe-area-inset-bottom)] pt-2 max-w-lg mx-auto">
          {tabs.map((tab) => {
            const isActive = currentScreen === tab.screen;
            const Icon = tab.icon;
            const isWishlist = tab.screen === 'wishlist';

            return (
              <motion.button
                key={tab.screen}
                whileTap={{ scale: 0.9 }}
                onClick={() => navigateTo(tab.screen)}
                className="relative flex flex-col items-center gap-1 py-1 px-3 min-w-[56px]"
              >
                {isActive && (
                  <motion.div
                    layoutId="activeTab"
                    className="absolute -top-1 w-8 h-1 rounded-full bg-gradient-to-r from-[#c8956c] to-[#d4a574]"
                    transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                  />
                )}
                <div className="relative">
                  <Icon
                    className={`w-5 h-5 transition-colors duration-200 ${
                      isActive ? 'text-[#c8956c] dark:text-[#d4a574]' : 'text-muted-foreground'
                    }`}
                    strokeWidth={isActive ? 2.5 : 1.5}
                    fill={isActive && isWishlist ? 'currentColor' : 'none'}
                  />
                  {isWishlist && wishlist.length > 0 && (
                    <span className="absolute -top-1 -right-2 w-4 h-4 bg-red-500 text-white text-[9px] font-bold rounded-full flex items-center justify-center">
                      {wishlist.length}
                    </span>
                  )}
                </div>
                <span
                  className={`text-[10px] font-medium transition-colors duration-200 ${
                    isActive ? 'text-[#c8956c] dark:text-[#d4a574]' : 'text-muted-foreground'
                  }`}
                >
                  {tab.label}
                </span>
              </motion.button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
