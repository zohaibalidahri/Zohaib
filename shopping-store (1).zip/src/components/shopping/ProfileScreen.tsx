'use client';

import { motion } from 'framer-motion';
import { useAppStore } from '@/store/useAppStore';
import {
  ArrowLeft, Package, Heart, MapPin, CreditCard, Bell,
  HelpCircle, MessageCircleQuestion, Shield, FileText,
  Settings, Moon, Sun, LogOut, ChevronRight, User,
  ShoppingBag, Star, MessageSquare
} from 'lucide-react';

const accountMenuItems = [
  { icon: Package, label: 'My Orders', screen: 'orders' as const },
  { icon: Heart, label: 'My Wishlist', screen: 'wishlist' as const },
  { icon: MapPin, label: 'Saved Addresses', screen: null },
  { icon: CreditCard, label: 'Payment Methods', screen: null },
];

const supportMenuItems = [
  { icon: Bell, label: 'Notifications', screen: 'notifications' as const },
  { icon: HelpCircle, label: 'Help & Support', screen: 'support' as const },
  { icon: MessageCircleQuestion, label: 'FAQ', screen: 'faq' as const },
];

const legalMenuItems = [
  { icon: Shield, label: 'Privacy Policy', screen: 'privacy' as const },
  { icon: FileText, label: 'Terms of Service', screen: 'terms' as const },
  { icon: Settings, label: 'Settings', screen: null },
];

export default function ProfileScreen() {
  const { user, theme, toggleTheme, navigateTo, orders, wishlist, cart } = useAppStore();

  const totalReviews = orders.reduce((acc) => acc + 2, 0);

  return (
    <div className="pb-24 min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-40 glass-strong">
        <div className="px-4 py-3">
          <h1 className="text-2xl font-bold text-foreground">Profile</h1>
        </div>
      </div>

      <div className="px-4 mt-4 flex flex-col gap-4">
        {/* Profile Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-card rounded-2xl card-shadow p-5 flex items-center gap-4"
        >
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#c8956c] to-[#d4a574] flex items-center justify-center flex-shrink-0">
            <User className="w-8 h-8 text-white" />
          </div>
          <div className="flex-1 min-w-0">
            <h2 className="font-bold text-foreground text-lg">{user.name}</h2>
            <p className="text-sm text-muted-foreground truncate">{user.email}</p>
            <p className="text-xs text-muted-foreground">{user.phone}</p>
          </div>
          <motion.button
            whileTap={{ scale: 0.9 }}
            className="w-10 h-10 rounded-xl bg-secondary/50 flex items-center justify-center"
          >
            <ChevronRight className="w-5 h-5 text-muted-foreground" />
          </motion.button>
        </motion.div>

        {/* Stats Row */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-3 gap-3"
        >
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => navigateTo('orders')}
            className="bg-card rounded-2xl card-shadow p-4 flex flex-col items-center gap-1"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center">
              <ShoppingBag className="w-5 h-5 text-white" />
            </div>
            <span className="text-lg font-bold text-foreground">{orders.length}</span>
            <span className="text-[10px] text-muted-foreground font-medium">Orders</span>
          </motion.button>
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => navigateTo('wishlist')}
            className="bg-card rounded-2xl card-shadow p-4 flex flex-col items-center gap-1"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-rose-400 to-pink-500 flex items-center justify-center">
              <Heart className="w-5 h-5 text-white" />
            </div>
            <span className="text-lg font-bold text-foreground">{wishlist.length}</span>
            <span className="text-[10px] text-muted-foreground font-medium">Wishlist</span>
          </motion.button>
          <div className="bg-card rounded-2xl card-shadow p-4 flex flex-col items-center gap-1">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-400 to-teal-500 flex items-center justify-center">
              <Star className="w-5 h-5 text-white" />
            </div>
            <span className="text-lg font-bold text-foreground">{totalReviews}</span>
            <span className="text-[10px] text-muted-foreground font-medium">Reviews</span>
          </div>
        </motion.div>

        {/* Account Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
        >
          <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 px-1">Account</h3>
          <div className="bg-card rounded-2xl card-shadow overflow-hidden">
            {accountMenuItems.map((item, i) => {
              const Icon = item.icon;
              return (
                <motion.button
                  key={item.label}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.03 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => item.screen && navigateTo(item.screen)}
                  className="w-full flex items-center gap-4 px-4 py-3.5 hover:bg-secondary/30 transition-colors"
                >
                  <div className="w-9 h-9 rounded-xl bg-secondary/50 flex items-center justify-center">
                    <Icon className="w-4.5 h-4.5 text-[#c8956c]" />
                  </div>
                  <span className="flex-1 text-left text-sm font-medium text-foreground">{item.label}</span>
                  <ChevronRight className="w-4 h-4 text-muted-foreground" />
                </motion.button>
              );
            })}
          </div>
        </motion.div>

        {/* Support Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 px-1">Support</h3>
          <div className="bg-card rounded-2xl card-shadow overflow-hidden">
            {supportMenuItems.map((item, i) => {
              const Icon = item.icon;
              return (
                <motion.button
                  key={item.label}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.03 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => item.screen && navigateTo(item.screen)}
                  className="w-full flex items-center gap-4 px-4 py-3.5 hover:bg-secondary/30 transition-colors"
                >
                  <div className="w-9 h-9 rounded-xl bg-secondary/50 flex items-center justify-center">
                    <Icon className="w-4.5 h-4.5 text-[#c8956c]" />
                  </div>
                  <span className="flex-1 text-left text-sm font-medium text-foreground">{item.label}</span>
                  <ChevronRight className="w-4 h-4 text-muted-foreground" />
                </motion.button>
              );
            })}
          </div>
        </motion.div>

        {/* Legal Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
        >
          <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 px-1">Legal</h3>
          <div className="bg-card rounded-2xl card-shadow overflow-hidden">
            {legalMenuItems.map((item, i) => {
              const Icon = item.icon;
              return (
                <motion.button
                  key={item.label}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.03 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => item.screen && navigateTo(item.screen)}
                  className="w-full flex items-center gap-4 px-4 py-3.5 hover:bg-secondary/30 transition-colors"
                >
                  <div className="w-9 h-9 rounded-xl bg-secondary/50 flex items-center justify-center">
                    <Icon className="w-4.5 h-4.5 text-[#c8956c]" />
                  </div>
                  <span className="flex-1 text-left text-sm font-medium text-foreground">{item.label}</span>
                  <ChevronRight className="w-4 h-4 text-muted-foreground" />
                </motion.button>
              );
            })}
          </div>
        </motion.div>

        {/* Dark Mode Toggle */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-card rounded-2xl card-shadow p-4 flex items-center justify-between"
        >
          <div className="flex items-center gap-4">
            <div className="w-9 h-9 rounded-xl bg-secondary/50 flex items-center justify-center">
              {theme === 'light' ? <Moon className="w-4.5 h-4.5 text-[#c8956c]" /> : <Sun className="w-4.5 h-4.5 text-[#c8956c]" />}
            </div>
            <span className="text-sm font-medium text-foreground">Dark Mode</span>
          </div>
          <button
            onClick={toggleTheme}
            className={`w-12 h-6 rounded-full transition-colors ${theme === 'dark' ? 'bg-[#c8956c]' : 'bg-secondary'}`}
          >
            <div className={`w-5 h-5 rounded-full bg-white shadow-sm transition-transform ${theme === 'dark' ? 'translate-x-6.5' : 'translate-x-0.5'}`} />
          </button>
        </motion.div>

        {/* Log Out */}
        <motion.button
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.35 }}
          whileTap={{ scale: 0.97 }}
          onClick={() => navigateTo('auth')}
          className="bg-card rounded-2xl card-shadow p-4 flex items-center justify-center gap-2 text-red-500 font-semibold text-sm"
        >
          <LogOut className="w-4 h-4" />
          Log Out
        </motion.button>

        {/* Version */}
        <div className="text-center pb-2">
          <p className="text-[10px] text-muted-foreground">Shopping Store v2.1.0</p>
        </div>
      </div>
    </div>
  );
}
