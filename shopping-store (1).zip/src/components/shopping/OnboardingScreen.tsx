'use client';

import { motion, AnimatePresence } from 'framer-motion';
import { useState } from 'react';
import { useAppStore } from '@/store/useAppStore';
import { ShoppingBag, ShieldCheck, Tag, ChevronRight } from 'lucide-react';

const pages = [
  {
    title: 'Discover Premium Products',
    description: 'Explore a curated collection of high-quality products from top brands around the world.',
    icon: ShoppingBag,
    gradient: 'from-[#c8956c] to-[#e8a87c]',
    bgGradient: 'from-amber-50 to-orange-50 dark:from-amber-950/20 dark:to-orange-950/20',
  },
  {
    title: 'Secure & Fast Checkout',
    description: 'Shop with confidence using our encrypted payment system and lightning-fast checkout process.',
    icon: ShieldCheck,
    gradient: 'from-emerald-500 to-teal-500',
    bgGradient: 'from-emerald-50 to-teal-50 dark:from-emerald-950/20 dark:to-teal-950/20',
  },
  {
    title: 'Best Deals Every Day',
    description: 'Never miss a deal! Get exclusive offers, flash sales, and daily discounts on your favorite items.',
    icon: Tag,
    gradient: 'from-rose-500 to-pink-500',
    bgGradient: 'from-rose-50 to-pink-50 dark:from-rose-950/20 dark:to-pink-950/20',
  },
];

export default function OnboardingScreen() {
  const [currentPage, setCurrentPage] = useState(0);
  const { navigateTo, setOnboardingCompleted } = useAppStore();

  const handleNext = () => {
    if (currentPage < pages.length - 1) {
      setCurrentPage(currentPage + 1);
    } else {
      handleComplete();
    }
  };

  const handleComplete = () => {
    setOnboardingCompleted(true);
    navigateTo('home');
  };

  const handleSkip = () => {
    handleComplete();
  };

  const page = pages[currentPage];
  const Icon = page.icon;

  return (
    <div className="fixed inset-0 flex flex-col bg-background">
      {/* Skip button */}
      <div className="flex justify-end p-4">
        {currentPage < pages.length - 1 && (
          <motion.button
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            onClick={handleSkip}
            className="text-sm text-muted-foreground hover:text-foreground transition-colors px-3 py-1"
          >
            Skip
          </motion.button>
        )}
      </div>

      {/* Content */}
      <div className="flex-1 flex flex-col items-center justify-center px-8">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentPage}
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            transition={{ duration: 0.3 }}
            className="flex flex-col items-center text-center gap-8"
          >
            {/* Illustration */}
            <motion.div
              initial={{ scale: 0.8, rotate: -10 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{ type: 'spring', stiffness: 200, damping: 15 }}
              className={`w-48 h-48 rounded-3xl bg-gradient-to-br ${page.bgGradient} flex items-center justify-center relative overflow-hidden`}
            >
              <motion.div
                animate={{
                  y: [0, -8, 0],
                  rotate: [0, 5, -5, 0],
                }}
                transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
              >
                <div className={`w-24 h-24 rounded-2xl bg-gradient-to-br ${page.gradient} flex items-center justify-center shadow-xl`}>
                  <Icon className="w-12 h-12 text-white" strokeWidth={1.5} />
                </div>
              </motion.div>
              {/* Decorative circles */}
              <motion.div
                className="absolute top-4 right-4 w-8 h-8 rounded-full bg-gradient-to-br from-[#c8956c]/20 to-[#d4a574]/20"
                animate={{ scale: [1, 1.3, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
              />
              <motion.div
                className="absolute bottom-6 left-6 w-6 h-6 rounded-full bg-gradient-to-br from-[#c8956c]/15 to-[#d4a574]/15"
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ duration: 2.5, repeat: Infinity, delay: 0.5 }}
              />
            </motion.div>

            {/* Text */}
            <div className="flex flex-col gap-3 max-w-sm">
              <h2 className="text-2xl font-bold text-foreground">{page.title}</h2>
              <p className="text-muted-foreground leading-relaxed">{page.description}</p>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Bottom controls */}
      <div className="p-8 flex flex-col items-center gap-6">
        {/* Progress dots */}
        <div className="flex gap-2">
          {pages.map((_, i) => (
            <motion.div
              key={i}
              className="h-2 rounded-full"
              animate={{
                width: i === currentPage ? 24 : 8,
                backgroundColor: i === currentPage ? '#c8956c' : '#e8e0d8',
              }}
              transition={{ duration: 0.3 }}
            />
          ))}
        </div>

        {/* Button */}
        <motion.button
          whileTap={{ scale: 0.97 }}
          whileHover={{ scale: 1.02 }}
          onClick={handleNext}
          className="w-full max-w-sm h-14 rounded-2xl bg-gradient-to-r from-[#c8956c] to-[#d4a574] text-white font-semibold text-base flex items-center justify-center gap-2 shadow-lg"
        >
          {currentPage === pages.length - 1 ? 'Get Started' : 'Next'}
          <ChevronRight className="w-5 h-5" />
        </motion.button>
      </div>
    </div>
  );
}
