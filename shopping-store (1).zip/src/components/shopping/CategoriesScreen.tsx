'use client';

import { motion } from 'framer-motion';
import { useAppStore } from '@/store/useAppStore';
import { categories } from '@/data/categories';
import { Search, Smartphone, Shirt, Home, Sparkles, Dumbbell, BookOpen, Gamepad2, ShoppingBasket, Gem, Car, Flower2, Music } from 'lucide-react';
import { useState, React } from 'react';

const catIconMap: Record<string, React.ComponentType<{className?: string}>> = {
  Smartphone, Shirt, Home, Sparkles, Dumbbell, BookOpen, Gamepad2, ShoppingBasket, Gem, Car, Flower2, Music,
};

export default function CategoriesScreen() {
  const { navigateTo, setSelectedCategory } = useAppStore();
  const [searchQuery, setSearchQuery] = useState('');

  const filteredCategories = categories.filter((cat) =>
    cat.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleCategoryTap = (catName: string) => {
    setSelectedCategory(catName);
    navigateTo('product-listing');
  };

  return (
    <div className="pb-24 min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-40 glass-strong">
        <div className="px-4 py-3">
          <h1 className="text-2xl font-bold text-foreground">Categories</h1>
        </div>
        {/* Search */}
        <div className="px-4 pb-3">
          <div className="flex items-center gap-3 px-4 py-2.5 rounded-2xl bg-secondary/50 border border-border/50">
            <Search className="w-4 h-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search categories..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="flex-1 bg-transparent text-sm text-foreground outline-none placeholder:text-muted-foreground"
            />
          </div>
        </div>
      </div>

      {/* Category Grid */}
      <div className="px-4 mt-2">
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          {filteredCategories.map((cat, i) => (
            <motion.button
              key={cat.id}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05, duration: 0.3 }}
              whileTap={{ scale: 0.95 }}
              whileHover={{ scale: 1.03 }}
              onClick={() => handleCategoryTap(cat.name)}
              className="relative overflow-hidden rounded-2xl p-4 flex flex-col items-center gap-3 card-shadow bg-card group"
            >
              <motion.div
                className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${cat.gradient} flex items-center justify-center shadow-lg`}
                whileHover={{ rotate: [0, -5, 5, 0] }}
                transition={{ duration: 0.4 }}
              >
                {(() => { const IconComp = catIconMap[cat.icon]; return IconComp ? <IconComp className="w-8 h-8 text-white" /> : null; })()}
              </motion.div>
              <div className="text-center">
                <p className="font-semibold text-sm text-foreground">{cat.name}</p>
                <p className="text-[10px] text-muted-foreground mt-0.5">{cat.productCount} items</p>
              </div>
              {/* Glow on hover */}
              <div className={`absolute inset-0 bg-gradient-to-br ${cat.gradient} opacity-0 group-hover:opacity-5 transition-opacity duration-300`} />
            </motion.button>
          ))}
        </div>
      </div>
    </div>
  );
}
