'use client';

import { motion, AnimatePresence } from 'framer-motion';
import { useState } from 'react';
import { useAppStore, Order } from '@/store/useAppStore';
import {
  ArrowLeft, MapPin, Truck, CreditCard, CheckCircle2,
  ChevronRight, ShieldCheck, Lock
} from 'lucide-react';
import { toast } from 'sonner';

const steps = ['Address', 'Shipping', 'Payment', 'Review'];

export default function CheckoutScreen() {
  const {
    checkoutStep, setCheckoutStep, shippingAddress, setShippingAddress,
    shippingMethod, setShippingMethod, paymentMethod, setPaymentMethod,
    getCartTotal, addOrder, navigateTo, cart, goBack, user
  } = useAppStore();

  const [isPlacing, setIsPlacing] = useState(false);
  const [orderPlaced, setOrderPlaced] = useState(false);

  const subtotal = getCartTotal();
  const deliveryFee = shippingMethod === 'express' ? 9.99 : shippingMethod === 'sameday' ? 14.99 : subtotal > 50 ? 0 : 4.99;
  const tax = subtotal * 0.08;
  const total = subtotal + deliveryFee + tax;

  const [localAddress, setLocalAddress] = useState(shippingAddress);

  const handleNext = () => {
    if (checkoutStep < 3) {
      if (checkoutStep === 0) {
        setShippingAddress(localAddress);
      }
      setCheckoutStep(checkoutStep + 1);
    }
  };

  const handlePlaceOrder = async () => {
    setIsPlacing(true);
    // Simulate order processing
    await new Promise((r) => setTimeout(r, 2000));
    const order: Order = {
      id: `ORD-${Date.now()}`,
      items: [...cart],
      total,
      status: 'pending',
      date: new Date().toLocaleDateString(),
      address: `${localAddress.address}, ${localAddress.city}`,
      paymentMethod,
    };
    addOrder(order);
    setIsPlacing(false);
    setOrderPlaced(true);
    toast('Order placed successfully!', { description: `Order #${order.id}` });
  };

  if (orderPlaced) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center px-6">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: 'spring', stiffness: 200, damping: 15 }}
          className="flex flex-col items-center gap-4"
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: 'spring' }}
            className="w-24 h-24 rounded-full bg-emerald-500/10 flex items-center justify-center"
          >
            <motion.div
              initial={{ scale: 0, rotate: -90 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{ delay: 0.4, type: 'spring' }}
            >
              <CheckCircle2 className="w-14 h-14 text-emerald-500" />
            </motion.div>
          </motion.div>
          <h2 className="text-2xl font-bold text-foreground">Order Confirmed!</h2>
          <p className="text-muted-foreground text-center">
            Your order has been placed successfully. You&apos;ll receive a confirmation soon.
          </p>
          <motion.button
            whileTap={{ scale: 0.97 }}
            onClick={() => {
              setOrderPlaced(false);
              setCheckoutStep(0);
              navigateTo('home');
            }}
            className="mt-4 px-8 py-3 rounded-2xl bg-gradient-to-r from-[#c8956c] to-[#d4a574] text-white font-semibold"
          >
            Continue Shopping
          </motion.button>
        </motion.div>
        {/* Confetti-like decorative elements */}
        {[...Array(8)].map((_, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 1, y: 0 }}
            animate={{ opacity: 0, y: -200, x: (Math.random() - 0.5) * 300 }}
            transition={{ duration: 1.5, delay: 0.2 + i * 0.1 }}
            className="fixed w-3 h-3 rounded-full"
            style={{
              backgroundColor: ['#c8956c', '#d4a574', '#e8a87c', '#f5c6a0', '#ef4444', '#f59e0b', '#10b981', '#8b5cf6'][i],
              bottom: '40%',
              left: '50%',
            }}
          />
        ))}
      </div>
    );
  }

  return (
    <div className="pb-32 min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-40 glass-strong">
        <div className="flex items-center gap-3 px-4 py-3">
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={checkoutStep > 0 ? () => setCheckoutStep(checkoutStep - 1) : goBack}
            className="w-10 h-10 rounded-xl bg-secondary/50 flex items-center justify-center"
          >
            <ArrowLeft className="w-5 h-5 text-foreground" />
          </motion.button>
          <h1 className="text-lg font-bold text-foreground">Checkout</h1>
        </div>

        {/* Step indicator */}
        <div className="px-4 pb-3">
          <div className="flex items-center justify-between">
            {steps.map((step, i) => (
              <div key={step} className="flex items-center">
                <div className="flex flex-col items-center">
                  <motion.div
                    animate={{
                      backgroundColor: i <= checkoutStep ? '#c8956c' : 'var(--secondary)',
                      scale: i === checkoutStep ? 1.1 : 1,
                    }}
                    className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold"
                    style={{ color: i <= checkoutStep ? 'white' : 'var(--muted-foreground)' }}
                  >
                    {i < checkoutStep ? '✓' : i + 1}
                  </motion.div>
                  <span className="text-[10px] text-muted-foreground mt-1">{step}</span>
                </div>
                {i < steps.length - 1 && (
                  <div className="w-8 sm:w-16 h-0.5 mx-1">
                    <motion.div
                      className="h-full rounded-full"
                      animate={{ backgroundColor: i < checkoutStep ? '#c8956c' : 'var(--border)' }}
                    />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="px-4 mt-4">
        <AnimatePresence mode="wait">
          {/* Step 0: Address */}
          {checkoutStep === 0 && (
            <motion.div
              key="address"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="flex flex-col gap-4"
            >
              <div className="flex items-center gap-2 mb-2">
                <MapPin className="w-5 h-5 text-[#c8956c]" />
                <h2 className="font-bold text-foreground">Shipping Address</h2>
              </div>
              {[
                { key: 'name' as const, label: 'Full Name', placeholder: user.name },
                { key: 'phone' as const, label: 'Phone Number', placeholder: user.phone },
                { key: 'address' as const, label: 'Address', placeholder: 'Enter your address' },
                { key: 'city' as const, label: 'City', placeholder: 'Enter city' },
                { key: 'zip' as const, label: 'ZIP Code', placeholder: 'Enter ZIP' },
              ].map((field) => (
                <div key={field.key}>
                  <label className="text-sm font-medium text-foreground mb-1 block">{field.label}</label>
                  <input
                    type="text"
                    value={localAddress[field.key]}
                    onChange={(e) => setLocalAddress({ ...localAddress, [field.key]: e.target.value })}
                    placeholder={field.placeholder}
                    className="w-full px-4 py-3 rounded-xl bg-secondary/30 border border-border/30 text-sm text-foreground outline-none focus:border-[#c8956c] transition-colors placeholder:text-muted-foreground"
                  />
                </div>
              ))}
            </motion.div>
          )}

          {/* Step 1: Shipping */}
          {checkoutStep === 1 && (
            <motion.div
              key="shipping"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="flex flex-col gap-3"
            >
              <div className="flex items-center gap-2 mb-2">
                <Truck className="w-5 h-5 text-[#c8956c]" />
                <h2 className="font-bold text-foreground">Shipping Method</h2>
              </div>
              {[
                { id: 'standard', label: 'Standard Delivery', time: '5-7 business days', price: subtotal > 50 ? 'Free' : '$4.99' },
                { id: 'express', label: 'Express Delivery', time: '2-3 business days', price: '$9.99' },
                { id: 'sameday', label: 'Same Day Delivery', time: 'Today (order before 2 PM)', price: '$14.99' },
              ].map((option) => (
                <motion.button
                  key={option.id}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => setShippingMethod(option.id)}
                  className={`w-full flex items-center justify-between p-4 rounded-2xl border-2 transition-colors ${
                    shippingMethod === option.id
                      ? 'border-[#c8956c] bg-[#c8956c]/5'
                      : 'border-border/30 bg-card'
                  }`}
                >
                  <div className="text-left">
                    <p className="font-semibold text-sm text-foreground">{option.label}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{option.time}</p>
                  </div>
                  <span className={`font-bold text-sm ${option.price === 'Free' ? 'text-emerald-500' : 'text-foreground'}`}>
                    {option.price}
                  </span>
                </motion.button>
              ))}
            </motion.div>
          )}

          {/* Step 2: Payment */}
          {checkoutStep === 2 && (
            <motion.div
              key="payment"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="flex flex-col gap-3"
            >
              <div className="flex items-center gap-2 mb-2">
                <CreditCard className="w-5 h-5 text-[#c8956c]" />
                <h2 className="font-bold text-foreground">Payment Method</h2>
              </div>
              {[
                { id: 'card', label: 'Credit/Debit Card', desc: 'Visa, Mastercard, Amex', icon: '💳' },
                { id: 'wallet', label: 'Digital Wallet', desc: 'Apple Pay, Google Pay', icon: '📱' },
                { id: 'cod', label: 'Cash on Delivery', desc: 'Pay when you receive', icon: '💵' },
              ].map((option) => (
                <motion.button
                  key={option.id}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => setPaymentMethod(option.id)}
                  className={`w-full flex items-center gap-4 p-4 rounded-2xl border-2 transition-colors ${
                    paymentMethod === option.id
                      ? 'border-[#c8956c] bg-[#c8956c]/5'
                      : 'border-border/30 bg-card'
                  }`}
                >
                  <span className="text-2xl">{option.icon}</span>
                  <div className="text-left">
                    <p className="font-semibold text-sm text-foreground">{option.label}</p>
                    <p className="text-xs text-muted-foreground">{option.desc}</p>
                  </div>
                </motion.button>
              ))}

              <div className="flex items-center gap-2 mt-2 p-3 rounded-xl bg-emerald-500/5">
                <ShieldCheck className="w-4 h-4 text-emerald-500" />
                <span className="text-xs text-emerald-600 dark:text-emerald-400">Your payment info is encrypted and secure</span>
              </div>
            </motion.div>
          )}

          {/* Step 3: Review */}
          {checkoutStep === 3 && (
            <motion.div
              key="review"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="flex flex-col gap-4"
            >
              <h2 className="font-bold text-foreground">Order Review</h2>

              {/* Items */}
              <div className="bg-card rounded-2xl card-shadow p-4 flex flex-col gap-3">
                {cart.map((item) => (
                  <div key={item.product.id} className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-lg flex-shrink-0 overflow-hidden">
                      <img src={item.product.image} alt={item.product.name} className="w-full h-full object-cover" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground line-clamp-1">{item.product.name}</p>
                      <p className="text-xs text-muted-foreground">Qty: {item.quantity}</p>
                    </div>
                    <span className="text-sm font-bold text-foreground">${(item.product.price * item.quantity).toFixed(2)}</span>
                  </div>
                ))}
              </div>

              {/* Address */}
              <div className="bg-card rounded-2xl card-shadow p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-[#c8956c]" />
                    <span className="font-semibold text-sm text-foreground">Address</span>
                  </div>
                </div>
                <p className="text-sm text-muted-foreground mt-2">
                  {localAddress.name || user.name}<br />
                  {localAddress.address || 'No address'}<br />
                  {localAddress.city} {localAddress.zip}
                </p>
              </div>

              {/* Shipping & Payment */}
              <div className="bg-card rounded-2xl card-shadow p-4 flex flex-col gap-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Shipping</span>
                  <span className="text-sm font-medium text-foreground capitalize">{shippingMethod}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Payment</span>
                  <span className="text-sm font-medium text-foreground capitalize">{paymentMethod === 'cod' ? 'Cash on Delivery' : paymentMethod === 'wallet' ? 'Digital Wallet' : 'Card'}</span>
                </div>
              </div>

              {/* Total */}
              <div className="bg-card rounded-2xl card-shadow p-4">
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span className="text-foreground">${subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-muted-foreground">Delivery</span>
                  <span className="text-foreground">${deliveryFee.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-muted-foreground">Tax</span>
                  <span className="text-foreground">${tax.toFixed(2)}</span>
                </div>
                <div className="h-px bg-border/30" />
                <div className="flex justify-between mt-2">
                  <span className="font-bold text-foreground">Total</span>
                  <span className="font-bold text-lg text-foreground">${total.toFixed(2)}</span>
                </div>
              </div>

              <div className="flex items-center gap-2 p-3 rounded-xl bg-[#c8956c]/5">
                <Lock className="w-4 h-4 text-[#c8956c]" />
                <span className="text-xs text-[#c8956c]">Secured by 256-bit SSL encryption</span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Bottom Button */}
      <div className="fixed bottom-0 left-0 right-0 z-40 glass-strong p-4 pb-[calc(1rem+env(safe-area-inset-bottom))]">
        <div className="max-w-lg mx-auto">
          <motion.button
            whileTap={{ scale: 0.97 }}
            onClick={checkoutStep < 3 ? handleNext : handlePlaceOrder}
            disabled={isPlacing}
            className="w-full h-14 rounded-2xl bg-gradient-to-r from-[#c8956c] to-[#d4a574] text-white font-semibold text-base flex items-center justify-center gap-2 disabled:opacity-60"
          >
            {isPlacing ? (
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full"
              />
            ) : checkoutStep < 3 ? (
              'Continue'
            ) : (
              `Place Order · $${total.toFixed(2)}`
            )}
          </motion.button>
        </div>
      </div>
    </div>
  );
}
