'use client';

import { motion } from 'framer-motion';
import { useState } from 'react';
import { useAppStore } from '@/store/useAppStore';
import { getProductById, getProductsByCategory } from '@/data/products';
import ProductCard from './ProductCard';
import {
  ArrowLeft, Heart, Share2, Star, Minus, Plus, Truck,
  RotateCcw, ShieldCheck, ChevronRight
} from 'lucide-react';
import { toast } from 'sonner';

export default function ProductDetailScreen() {
  const { selectedProductId, goBack, toggleWishlist, wishlist, addToCart, navigateTo } = useAppStore();
  const product = getProductById(selectedProductId || 0);
  const [selectedColor, setSelectedColor] = useState(product?.colors[0] || '');
  const [selectedSize, setSelectedSize] = useState(product?.sizes[0] || '');
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState<'description' | 'reviews' | 'specs'>('description');
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  if (!product) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background">
        <p className="text-muted-foreground">Product not found</p>
      </div>
    );
  }

  const isWished = wishlist.includes(product.id);
  const similarProducts = getProductsByCategory(product.category).filter((p) => p.id !== product.id);

  // Create gallery images (main + 2 additional views)
  const images = [product.image, product.image, product.image];

  const handleAddToCart = () => {
    addToCart(product, selectedColor, selectedSize, quantity);
    toast('Added to cart', { description: `${quantity}x ${product.name}` });
  };

  const handleBuyNow = () => {
    addToCart(product, selectedColor, selectedSize, quantity);
    navigateTo('checkout');
  };

  const handleWishlist = () => {
    toggleWishlist(product.id);
    toast(isWished ? 'Removed from wishlist' : 'Added to wishlist', {
      description: product.name,
    });
  };

  // Mock reviews
  const reviews = [
    { name: 'Sarah M.', rating: 5, comment: 'Absolutely love this product! Exceeded my expectations.', date: '2 days ago' },
    { name: 'James K.', rating: 4, comment: 'Great quality for the price. Would recommend to others.', date: '1 week ago' },
    { name: 'Emily R.', rating: 5, comment: 'Fast shipping and exactly as described. Very happy!', date: '2 weeks ago' },
  ];

  const ratingBreakdown = [
    { stars: 5, count: 65 },
    { stars: 4, count: 20 },
    { stars: 3, count: 10 },
    { stars: 2, count: 3 },
    { stars: 1, count: 2 },
  ];

  return (
    <div className="pb-28 min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-40 glass-strong">
        <div className="flex items-center justify-between px-4 py-3">
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={goBack}
            className="w-10 h-10 rounded-xl bg-secondary/50 flex items-center justify-center"
          >
            <ArrowLeft className="w-5 h-5 text-foreground" />
          </motion.button>
          <div className="flex items-center gap-2">
            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={handleWishlist}
              className="w-10 h-10 rounded-xl bg-secondary/50 flex items-center justify-center"
            >
              <Heart className={`w-5 h-5 ${isWished ? 'fill-red-500 text-red-500' : 'text-foreground'}`} />
            </motion.button>
            <motion.button
              whileTap={{ scale: 0.9 }}
              className="w-10 h-10 rounded-xl bg-secondary/50 flex items-center justify-center"
            >
              <Share2 className="w-5 h-5 text-foreground" />
            </motion.button>
          </div>
        </div>
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.3 }}
      >
        {/* Image Gallery */}
        <div className="relative">
          <div className="flex overflow-x-auto snap-x snap-mandatory hide-scrollbar">
            {images.map((img, i) => (
              <div
                key={i}
                className="w-full flex-shrink-0 snap-center"
              >
                <div className="aspect-square overflow-hidden">
                  <img src={img} alt={`${product.name} view ${i + 1}`} className="w-full h-full object-cover" />
                </div>
              </div>
            ))}
          </div>
          {/* Image dots */}
          <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5">
            {images.map((_, i) => (
              <div
                key={i}
                className={`w-2 h-2 rounded-full transition-colors ${i === 0 ? 'bg-[#c8956c]' : 'bg-white/50'}`}
              />
            ))}
          </div>
        </div>

        {/* Product Info */}
        <div className="px-4 mt-4 flex flex-col gap-4">
          {/* Title & Rating */}
          <div>
            <h1 className="text-xl font-bold text-foreground leading-tight">{product.name}</h1>
            <div className="flex items-center gap-2 mt-2">
              <div className="flex items-center gap-1">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-4 h-4 ${i < Math.floor(product.rating) ? 'fill-amber-400 text-amber-400' : 'text-gray-300'}`}
                  />
                ))}
              </div>
              <span className="text-sm font-medium text-foreground">{product.rating}</span>
              <span className="text-sm text-muted-foreground">({product.reviewCount} reviews)</span>
            </div>
          </div>

          {/* Price */}
          <div className="flex items-center gap-3">
            <span className="text-2xl font-bold text-foreground">${product.price}</span>
            {product.discount > 0 && (
              <>
                <span className="text-base text-muted-foreground line-through">${product.originalPrice}</span>
                <span className="px-2 py-0.5 rounded-lg bg-red-500/10 text-red-500 text-sm font-bold">
                  -{product.discount}%
                </span>
              </>
            )}
          </div>

          {/* Color Selector */}
          {product.colors.length > 0 && (
            <div>
              <h3 className="text-sm font-semibold text-foreground mb-2">Color</h3>
              <div className="flex gap-2">
                {product.colors.map((color) => (
                  <motion.button
                    key={color}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => setSelectedColor(color)}
                    className={`w-10 h-10 rounded-full border-2 transition-colors ${
                      selectedColor === color ? 'border-[#c8956c]' : 'border-transparent'
                    }`}
                    style={{ backgroundColor: color }}
                  >
                    {selectedColor === color && (
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        className="w-full h-full rounded-full flex items-center justify-center"
                      >
                        <span className="text-white text-xs font-bold">✓</span>
                      </motion.div>
                    )}
                  </motion.button>
                ))}
              </div>
            </div>
          )}

          {/* Size Selector */}
          {product.sizes.length > 0 && product.sizes[0] !== 'One Size' && (
            <div>
              <h3 className="text-sm font-semibold text-foreground mb-2">Size</h3>
              <div className="flex gap-2 flex-wrap">
                {product.sizes.map((size) => (
                  <motion.button
                    key={size}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setSelectedSize(size)}
                    className={`px-4 py-2 rounded-xl text-sm font-medium transition-colors ${
                      selectedSize === size
                        ? 'bg-[#c8956c] text-white'
                        : 'bg-secondary/50 text-foreground'
                    }`}
                  >
                    {size}
                  </motion.button>
                ))}
              </div>
            </div>
          )}

          {/* Quantity */}
          <div>
            <h3 className="text-sm font-semibold text-foreground mb-2">Quantity</h3>
            <div className="flex items-center gap-4">
              <motion.button
                whileTap={{ scale: 0.9 }}
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                className="w-10 h-10 rounded-xl bg-secondary/50 flex items-center justify-center"
              >
                <Minus className="w-4 h-4 text-foreground" />
              </motion.button>
              <span className="text-lg font-bold text-foreground w-8 text-center">{quantity}</span>
              <motion.button
                whileTap={{ scale: 0.9 }}
                onClick={() => setQuantity(Math.min(product.stockCount, quantity + 1))}
                className="w-10 h-10 rounded-xl bg-secondary/50 flex items-center justify-center"
              >
                <Plus className="w-4 h-4 text-foreground" />
              </motion.button>
            </div>
          </div>

          {/* Delivery Info */}
          <div className="bg-secondary/30 rounded-2xl p-4 flex flex-col gap-3">
            <div className="flex items-center gap-3">
              <Truck className="w-5 h-5 text-[#c8956c]" />
              <div>
                <p className="text-sm font-medium text-foreground">Free Delivery</p>
                <p className="text-xs text-muted-foreground">Estimated: {product.deliveryDays}-{product.deliveryDays + 2} days</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <RotateCcw className="w-5 h-5 text-[#c8956c]" />
              <div>
                <p className="text-sm font-medium text-foreground">7-Day Returns</p>
                <p className="text-xs text-muted-foreground">Hassle-free return policy</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <ShieldCheck className="w-5 h-5 text-[#c8956c]" />
              <div>
                <p className="text-sm font-medium text-foreground">Secure Payment</p>
                <p className="text-xs text-muted-foreground">256-bit SSL encryption</p>
              </div>
            </div>
          </div>

          {/* Tabs */}
          <div className="flex gap-1 bg-secondary/30 rounded-xl p-1">
            {(['description', 'reviews', 'specs'] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`flex-1 py-2 rounded-lg text-sm font-medium capitalize transition-colors ${
                  activeTab === tab
                    ? 'bg-card text-foreground shadow-sm'
                    : 'text-muted-foreground'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>

          {/* Tab Content */}
          <div className="min-h-[120px]">
            {activeTab === 'description' && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex flex-col gap-3"
              >
                <p className="text-sm text-muted-foreground leading-relaxed">{product.description}</p>
                <div className="flex flex-col gap-1.5">
                  {product.features.map((f) => (
                    <div key={f} className="flex items-center gap-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-[#c8956c]" />
                      <span className="text-sm text-foreground">{f}</span>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {activeTab === 'reviews' && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex flex-col gap-4"
              >
                {/* Rating breakdown */}
                <div className="flex flex-col gap-1.5">
                  {ratingBreakdown.map((r) => (
                    <div key={r.stars} className="flex items-center gap-2">
                      <span className="text-xs text-muted-foreground w-6">{r.stars}★</span>
                      <div className="flex-1 h-2 rounded-full bg-secondary/50 overflow-hidden">
                        <div
                          className="h-full bg-amber-400 rounded-full"
                          style={{ width: `${r.count}%` }}
                        />
                      </div>
                      <span className="text-xs text-muted-foreground w-6">{r.count}%</span>
                    </div>
                  ))}
                </div>
                {/* Reviews */}
                <div className="flex flex-col gap-3">
                  {reviews.map((review, i) => (
                    <div key={i} className="bg-secondary/30 rounded-xl p-3">
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-sm text-foreground">{review.name}</span>
                        <span className="text-xs text-muted-foreground">{review.date}</span>
                      </div>
                      <div className="flex items-center gap-0.5 mt-1">
                        {[...Array(5)].map((_, j) => (
                          <Star
                            key={j}
                            className={`w-3 h-3 ${j < review.rating ? 'fill-amber-400 text-amber-400' : 'text-gray-300'}`}
                          />
                        ))}
                      </div>
                      <p className="text-sm text-muted-foreground mt-1.5">{review.comment}</p>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {activeTab === 'specs' && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex flex-col gap-2"
              >
                {[
                  ['Category', product.category],
                  ['In Stock', product.inStock ? 'Yes' : 'No'],
                  ['Stock Count', String(product.stockCount)],
                  ['Delivery', `${product.deliveryDays}-${product.deliveryDays + 2} business days`],
                  ['Colors Available', String(product.colors.length)],
                  ['Sizes Available', product.sizes.join(', ')],
                ].map(([key, val]) => (
                  <div key={key} className="flex justify-between py-2 border-b border-border/30">
                    <span className="text-sm text-muted-foreground">{key}</span>
                    <span className="text-sm font-medium text-foreground">{val}</span>
                  </div>
                ))}
              </motion.div>
            )}
          </div>

          {/* Similar Products */}
          {similarProducts.length > 0 && (
            <div>
              <h3 className="text-lg font-bold text-foreground mb-3">Similar Products</h3>
              <div className="flex gap-3 overflow-x-auto hide-scrollbar">
                {similarProducts.slice(0, 4).map((p, i) => (
                  <div key={p.id} className="min-w-[160px]">
                    <ProductCard product={p} index={i} />
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </motion.div>

      {/* Sticky Bottom Bar */}
      <div className="fixed bottom-0 left-0 right-0 z-40 glass-strong p-4 pb-[calc(1rem+env(safe-area-inset-bottom))]">
        <div className="flex gap-3 max-w-lg mx-auto">
          <motion.button
            whileTap={{ scale: 0.97 }}
            onClick={handleAddToCart}
            className="flex-1 h-14 rounded-2xl bg-secondary text-foreground font-semibold text-sm flex items-center justify-center gap-2"
          >
            Add to Cart
          </motion.button>
          <motion.button
            whileTap={{ scale: 0.97 }}
            onClick={handleBuyNow}
            className="flex-1 h-14 rounded-2xl bg-gradient-to-r from-[#c8956c] to-[#d4a574] text-white font-semibold text-sm flex items-center justify-center gap-2"
          >
            Buy Now
          </motion.button>
        </div>
      </div>
    </div>
  );
}
