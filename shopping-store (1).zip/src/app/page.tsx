'use client';

import { motion, AnimatePresence } from 'framer-motion';
import { useAppStore } from '@/store/useAppStore';
import { useEffect } from 'react';
import SplashScreen from '@/components/shopping/SplashScreen';
import OnboardingScreen from '@/components/shopping/OnboardingScreen';
import HomeScreen from '@/components/shopping/HomeScreen';
import BottomNav from '@/components/shopping/BottomNav';
import CategoriesScreen from '@/components/shopping/CategoriesScreen';
import ProductListingScreen from '@/components/shopping/ProductListingScreen';
import ProductDetailScreen from '@/components/shopping/ProductDetailScreen';
import CartScreen from '@/components/shopping/CartScreen';
import CheckoutScreen from '@/components/shopping/CheckoutScreen';
import WishlistScreen from '@/components/shopping/WishlistScreen';
import OrdersScreen from '@/components/shopping/OrdersScreen';
import ProfileScreen from '@/components/shopping/ProfileScreen';
import SearchScreen from '@/components/shopping/SearchScreen';
import AuthScreen from '@/components/shopping/AuthScreen';
import NotificationsScreen from '@/components/shopping/NotificationsScreen';
import SupportScreen from '@/components/shopping/SupportScreen';

function ScreenRenderer() {
  const { currentScreen, theme } = useAppStore();

  // Apply theme
  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark');
  }, [theme]);

  const screenMap: Record<string, React.ReactNode> = {
    splash: <SplashScreen />,
    onboarding: <OnboardingScreen />,
    home: <HomeScreen />,
    categories: <CategoriesScreen />,
    'product-listing': <ProductListingScreen />,
    'product-detail': <ProductDetailScreen />,
    cart: <CartScreen />,
    checkout: <CheckoutScreen />,
    wishlist: <WishlistScreen />,
    orders: <OrdersScreen />,
    profile: <ProfileScreen />,
    search: <SearchScreen />,
    auth: <AuthScreen />,
    notifications: <NotificationsScreen />,
    support: <SupportScreen />,
    faq: <SupportScreen />,
    privacy: <StaticPage title="Privacy Policy" />,
    terms: <StaticPage title="Terms of Service" />,
  };

  const showNav = !['splash', 'onboarding', 'checkout'].includes(currentScreen);

  return (
    <div className="min-h-screen bg-background">
      <AnimatePresence mode="wait">
        <motion.div
          key={currentScreen}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -8 }}
          transition={{ duration: 0.25, ease: 'easeOut' }}
        >
          {screenMap[currentScreen] || <HomeScreen />}
        </motion.div>
      </AnimatePresence>
      {showNav && <BottomNav />}
    </div>
  );
}

function StaticPage({ title }: { title: string }) {
  const { goBack } = useAppStore();
  return (
    <div className="pb-24 min-h-screen bg-background">
      <div className="sticky top-0 z-40 glass-strong">
        <div className="flex items-center gap-3 px-4 py-3">
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={goBack}
            className="w-10 h-10 rounded-xl bg-secondary/50 flex items-center justify-center"
          >
            <span className="text-foreground">←</span>
          </motion.button>
          <h1 className="text-lg font-bold text-foreground">{title}</h1>
        </div>
      </div>
      <div className="px-4 mt-4">
        <div className="bg-card rounded-2xl card-shadow p-6">
          <h2 className="text-lg font-bold text-foreground mb-3">{title}</h2>
          <p className="text-sm text-muted-foreground leading-relaxed">
            Last updated: January 1, 2025
          </p>
          <div className="mt-4 flex flex-col gap-3 text-sm text-muted-foreground leading-relaxed">
            <p>Welcome to Shopping Store. We are committed to protecting your privacy and ensuring a safe shopping experience.</p>
            <p>We collect only the information necessary to process your orders and improve your shopping experience. Your data is encrypted and stored securely.</p>
            <p>We never share your personal information with third parties without your consent. You can request deletion of your data at any time.</p>
            <p>For any questions or concerns, please contact our support team at support@shoppingstore.com.</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function Page() {
  return <ScreenRenderer />;
}
