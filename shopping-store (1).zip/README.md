# Shopping Store — Premium E-Commerce Application

A beautifully crafted e-commerce application built with **Next.js 16**, **React 19**, **TypeScript**, **Tailwind CSS 4**, and **shadcn/ui** — featuring a stunning 3D glassmorphism design with smooth Framer Motion animations and a complete shopping experience.

---

## Features

- **18+ Screens** — Splash, Onboarding, Home, Categories, Product Listing, Product Detail, Cart, Checkout, Wishlist, Orders, Profile, Search, Auth, Notifications, Support, and more
- **3D Glassmorphism UI** — Premium glass-effect design with depth and elegance
- **Dark & Light Mode** — Full theme support with smooth transitions
- **Smooth Animations** — Framer Motion powered transitions and interactions
- **24 Products** — AI-generated product imagery across 12 categories
- **Banner Carousel** — Interactive hero banners on the home screen
- **Shopping Cart** — Full add-to-cart, quantity management, and checkout flow
- **Wishlist** — Save favorite products for later
- **Order History** — Track past orders and order status
- **Search** — Search products by name, category, and description
- **Responsive Design** — Optimized for mobile, tablet, and desktop
- **Accessibility** — Keyboard navigation and ARIA support via Radix UI primitives

---

## Tech Stack

| Technology | Version | Purpose |
|---|---|---|
| Next.js | 16.1+ | React framework with App Router |
| React | 19 | UI library |
| TypeScript | 5 | Type safety |
| Tailwind CSS | 4 | Utility-first styling |
| shadcn/ui | Latest | Component library (New York style) |
| Framer Motion | 12+ | Animations and transitions |
| Zustand | 5 | State management |
| Lucide React | Latest | Icon library |
| Prisma | 6 | Database ORM |
| Sonner | 2 | Toast notifications |

---

## Getting Started

### Prerequisites

- **Node.js** 18.17 or later
- **npm**, **yarn**, **pnpm**, or **bun**

### Installation

1. **Extract the package** (if you received a ZIP file):
   ```bash
   unzip shopping-store.zip -d shopping-store
   cd shopping-store
   ```

2. **Install dependencies**:
   ```bash
   npm install
   ```

3. **Set up environment variables**:
   ```bash
   cp .env.example .env
   ```
   Edit `.env` with your database connection string.

4. **Generate Prisma client**:
   ```bash
   npx prisma generate
   ```

5. **Start the development server**:
   ```bash
   npm run dev
   ```

6. **Open your browser**:
   Navigate to [http://localhost:3000](http://localhost:3000)

### Build for Production

```bash
npm run build
npm start
```

---

## Deployment

### Vercel (Recommended)

1. Push the project to a Git repository
2. Import the repository on [vercel.com](https://vercel.com)
3. Vercel auto-detects Next.js and configures the build
4. Add environment variables in the Vercel dashboard
5. Deploy

### Netlify

1. Push the project to a Git repository
2. Import on [app.netlify.com](https://app.netlify.com)
3. Build command: `npm run build`
4. Publish directory: `.next`
5. Add the `@netlify/plugin-nextjs` plugin
6. Deploy

### Cloudflare Pages

1. Push the project to a Git repository
2. Import on Cloudflare Pages dashboard
3. Framework preset: **Next.js**
4. Build command: `npm run build`
5. Add `@cloudflare/next-on-pages` as a dev dependency if needed
6. Deploy

### Standard Node.js Hosting

```bash
npm run build
npm start
```

The server will start on port 3000 by default.

---

## Project Structure

```
shopping-store/
├── public/                    # Static assets
│   ├── images/
│   │   ├── banners/           # 3 hero banner images
│   │   └── products/          # 24 product images
│   ├── logo.svg
│   └── robots.txt
├── src/
│   ├── app/                   # Next.js App Router
│   │   ├── api/               # API routes
│   │   ├── globals.css        # Global styles + theme
│   │   ├── layout.tsx         # Root layout
│   │   └── page.tsx           # Main SPA entry point
│   ├── components/
│   │   ├── shopping/          # 18 app screen components
│   │   └── ui/                # 37 shadcn/ui components
│   ├── data/                  # Product & category data
│   ├── hooks/                 # Custom React hooks
│   ├── lib/                   # Utilities & Prisma client
│   └── store/                 # Zustand state management
├── prisma/                    # Database schema
├── .env.example               # Environment variable template
├── .gitignore                 # Git ignore rules
├── components.json            # shadcn/ui configuration
├── eslint.config.mjs          # ESLint configuration
├── next.config.ts             # Next.js configuration
├── package.json               # Project manifest
├── postcss.config.mjs         # PostCSS configuration
├── tailwind.config.ts         # Tailwind CSS configuration
└── tsconfig.json              # TypeScript configuration
```

---

## Available Scripts

| Script | Command | Description |
|---|---|---|
| Dev Server | `npm run dev` | Start development server on port 3000 |
| Build | `npm run build` | Create production build |
| Start | `npm start` | Start production server |
| Lint | `npm run lint` | Run ESLint checks |
| DB Push | `npm run db:push` | Push Prisma schema to database |
| DB Generate | `npm run db:generate` | Generate Prisma client |
| DB Migrate | `npm run db:migrate` | Run database migrations |
| DB Reset | `npm run db:reset` | Reset database |

---

## Customization

### Colors & Theme

The color system is defined in `tailwind.config.ts` using CSS custom properties. The main theme features a gold/warm palette. Modify the CSS variables in `src/app/globals.css` under `:root` and `.dark` selectors to change the color scheme.

### Products & Categories

Product data is defined in `src/data/products.ts` and categories in `src/data/categories.ts`. Edit these files to add, remove, or modify products and categories.

### Images

Replace images in `public/images/products/` and `public/images/banners/` with your own. Keep the same naming convention (`product-1.png`, `product-2.png`, etc.) or update the references in `src/data/products.ts`.

---

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

---

## License

This project is licensed for use as purchased. See the marketplace listing for license details.
